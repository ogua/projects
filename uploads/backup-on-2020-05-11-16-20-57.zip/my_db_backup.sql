#
# TABLE STRUCTURE FOR: attachment
#

DROP TABLE IF EXISTS `attachment`;

CREATE TABLE `attachment` (
  `idattachment` int(11) NOT NULL AUTO_INCREMENT,
  `idissue` int(10) NOT NULL,
  `path` varchar(200) NOT NULL,
  PRIMARY KEY (`idattachment`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: companies
#

DROP TABLE IF EXISTS `companies`;

CREATE TABLE `companies` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `companies` (`company_id`, `company_name`) VALUES ('1', 'Company 1');
INSERT INTO `companies` (`company_id`, `company_name`) VALUES ('2', 'Company 2');


#
# TABLE STRUCTURE FOR: department
#

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `iddepartment` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `department` varchar(45) NOT NULL DEFAULT '',
  `prefix` varchar(5) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`iddepartment`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;

INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('1', 'Administration', 'EA', 'img/logo/Administration.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('2', 'Agriculture,Livestock,Cooperation & Fisheries', 'ALCT', 'img/logo/Agriculture.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('3', 'Auqaf,Hajj,Religious,& Minorities', 'AUKD', 'img/logo/Auqaf.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('4', 'Establishment', 'EA', 'img/logo/Establishment.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('5', 'Excise,Taxation & Norcotics Control', 'ETD', 'img/logo/Excise%20&%20Taxation.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('6', 'Forestry,Environment & Wildlife', 'ENVD', 'img/logo/Environment.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('7', 'Elementary and Secondary Education', 'ESE', 'img/logo/Elementary%20&%20Secondary%20Education.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('8', 'Finance', 'FD', 'img/logo/Finance.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('9', 'Food', 'FDD', 'img/logo/Food.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('10', 'Health', 'HD', 'img/logo/Health.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('11', 'Home and Tribal Affairs', 'HA', 'img/logo/Home%20&%20Tribal%20Affairs.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('12', 'Higher Education,Archives & Libraries', 'HED', 'img/logo/hec.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('13', 'Housing', 'HSD', 'img/logo/Housing.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('14', 'Industries,Commerce & Technical Education', 'INDD', 'img/logo/Industries.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('15', 'Law,Parliamentary Affairs & Human Rights', 'LD', 'img/logo/Law.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('16', 'Local Govt. Rural Dev. & Election ', 'LGD', 'img/logo/Local%20Government.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('17', 'Planning and Development', 'PDD', 'img/logo/Planning%20&%20Development.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('18', 'Population Welfare', 'PWD', 'img/logo/Population%20Welfare.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('19', 'Revenue & Estate Department', 'REVD', 'img/logo/Revenue.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('20', 'ST&IT', 'ST&IT', 'img/logo/ST&IT.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('21', 'Sports,Tourism, Archealogy,Museum &Culture', '', 'img/logo/Tourism.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('22', 'Communication and Works', 'CWD', 'img/logo/Communication%20&%20Works(C&W).png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('23', 'Zakat, Ushr, Social Welfare,Special Education', 'ZUD', 'img/logo/Zakat%20Ushr.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('25', 'Energy and Power', 'EPD', 'img/logo/ena.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('26', 'Transport & Mass Transit ', 'TRAD', 'img/logo/Transport.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('27', 'Information and Public Relations', 'IPCD', 'img/logo/Information%20&%20Public%20Relations.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('28', 'Minerals Development', 'MD', 'img/logo/Minerals%20Development.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('29', 'Irrigation', 'IRD', 'img/logo/Irrigation.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('30', 'Inter Provincial Coordination', 'IPD', 'img/logo/Inter%20Provincial%20Coordinationl.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('31', 'Labor', 'LD', 'img/logo/Labor.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('32', 'Relief, Rehabilitation and Settlement', 'RRSD', 'img/logo/Relief,%20Rehabilitation%20&%20Settlementl.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('33', 'Public Health Engineering', 'PHED', 'img/logo/Public%20Health%20Engineering.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('34', 'Directorate of Information Technology', 'DOIT', 'img/logo/Directorate%20of%20Information%20Technology.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('35', 'Staff Training Institute', '', 'img/logo/Staff Training Institute.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('36', 'Advocate General', 'AGD', 'img/logo/Advocate%20General.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('37', 'Directorate of Fisheries', 'DOF', 'img/logo/Directorate%20of%20Fisheries.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('38', 'Employee Social Security Institution', 'ESSID', 'img/logo/Employee%20Social%20Security%20Institution.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('40', 'Chief Secretary', 'CS', 'img/logo/CS.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('41', 'Chief Minister', 'CM', 'img/logo/CM.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('42', 'FATA', 'FATA', 'img/logo/fata.png', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('43', 'Governor', '', '', '1');
INSERT INTO `department` (`iddepartment`, `department`, `prefix`, `picture`, `status`) VALUES ('100', 'Company (Main)', 'CO', 'img/logo/fata.png', '1');


#
# TABLE STRUCTURE FOR: designation
#

DROP TABLE IF EXISTS `designation`;

CREATE TABLE `designation` (
  `iddesignation` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`iddesignation`)
) ENGINE=MyISAM AUTO_INCREMENT=174 DEFAULT CHARSET=utf8;

INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('1', 'Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('2', 'Administrator', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('3', 'Section Officer (General).', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('4', 'Section Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('5', 'Special Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('6', 'Principal Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('7', 'Additional Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('8', 'Deputy Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('9', 'Assistant Director', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('10', 'Stenographer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('11', 'PA', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('12', 'Planning Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('13', 'Deputy Director', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('14', 'Advisor To CM', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('15', 'Special Assistant', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('16', 'Assistant', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('17', 'Budget Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('18', 'Director', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('19', 'Assistant Programmer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('20', 'RIC', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('21', 'Deputy Director IT, Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('22', 'Computer Operator', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('23', 'DS (R-I), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('24', 'Section Officer R-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('25', 'Section Officer R-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('26', 'Section Officer R-IV', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('27', 'Section Officer PSB', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('28', 'Section officer R-VI', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('29', 'Research Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('30', 'Section Officer (Budget & Account)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('31', 'Senior Private Secretary IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('32', 'PS-Special Secretary IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('33', 'Section Officer (General) Law', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('34', 'Steno Grapher IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('35', 'Deputy Secretary (Policy), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('36', 'Section Officer (R-III), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('37', 'Assistant Director (IT) IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('38', 'Principal Secretary IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('39', 'Section Officer (secret), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('40', 'Section Officer R-V, Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('41', 'Computer Operator IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('42', 'Section Officer (O&M), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('43', 'Section Officer (Litigation), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('44', 'Section Officer (admn) IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('45', 'Section Oficer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('46', 'Addl. Secretary HRD, Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('47', 'Deputy Secretary HRD, Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('48', 'Section Officer HRD-I, Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('49', 'Section Officer HRD-II, Establishmnet', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('50', 'PA to Additional Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('51', 'Additional Secretary Information', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('52', 'PS to Secretary Information', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('53', 'Data Processing Supervisor', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('54', 'Parliment Secretary', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('55', 'Legal Drafter', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('56', 'Deputy Legal Drafter-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('57', 'Deputy Legal Drafter-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('58', 'Assistant Legal Drafter-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('59', 'Assistant Legal Drafter-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('60', 'Assistant Legal Drafter-III', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('61', 'Assistant Legal Drafter-IV', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('62', 'Assistant Legal Drafter-V', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('63', 'Additional Secretary (Opinion)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('64', 'Section Officer (Opinion-I)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('65', 'Section Officer (Opinion-II)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('66', 'Assistant IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('67', 'Section Officer (Lit) IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('68', 'Section Officer-II  IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('69', 'Additional Secretary-I  IC&TE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('70', 'Translator', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('71', 'Deputy Secretary (Assembly)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('72', 'Section Officer (Assembly)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('73', 'Deputy Solicitor', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('74', 'Section Officer Litigation (Law)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('75', 'Human Rights', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('76', 'Section Officer Human Rights', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('77', 'Deputy Secretary (Admn) law', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('78', 'Deputy Secretary R-III, Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('79', 'Special Secretary (E), Establishmnet', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('80', 'Special Secretary (R), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('81', 'Addl. Secretary (E), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('82', 'Addl. Secretary (R), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('83', 'Addl. Secretary (Jud), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('84', 'Section officer (general)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('85', 'Computer Programmer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('86', 'Section Officer Imp-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('87', 'Section Officer Imp-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('88', 'Section Officer Imp-III', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('89', 'Gender Specialist-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('90', 'Gender Specialist-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('91', 'Senior Planning Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('92', 'Chief Planning Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('93', 'Assistant Statistical Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('94', 'Agri Business Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('95', 'Deputy Secretary (E), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('96', 'Section Officer (E-I), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('97', 'Section Officer (E-II), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('98', 'Section Officer (E-III), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('99', 'Section Officer (E-IV), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('100', 'Section Officer (E-V), Establishment', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('101', 'Deputy Secretary (Admin), Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('102', 'Section Officer (Avi-I), Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('103', 'Section Officer (Avi-II), Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('104', 'Section Officer (Budget), Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('105', 'Section Officer(Technical)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('106', 'Personal Assistant IC&TE (SA to CM for TE)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('107', 'Special Assistant to CM for Inudstries', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('108', 'JUNIOR CLERK', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('109', 'Director ESRU ', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('110', 'Deputy Secretary (Legal) ', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('111', 'DEPUTY SECRETARY-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('112', 'DEPUTY SECRETARY-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('113', 'DEPUTY SECRETARY LEAGAL', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('114', 'DEPUTY SECRETARY ADMIN', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('115', 'PLANNING OFFICER-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('116', 'PLANNING OFFICER-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('117', 'PLANNING OFFICER-III', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('118', 'ASSISTANT DIRECTOR EMIS-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('119', 'ASSISTANT DIRECTOR EMIS-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('120', 'ASSISTANT DIRECTOR EMIS-III', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('121', 'ASSISTANT DIRECTOR EMIS-IV', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('122', 'SECTION OFFICER (COMPLAINT)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('123', 'SECTION OFFICER (LITIGATION-I)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('124', 'SECTION OFFICER (LITIGATION-II)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('125', 'SECTION OFFICER (AUDIT)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('126', 'SECTION OFFICER (BUDGET AND ACCOUNT)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('127', 'SECTION OFFICER (BOARD AND TRAINING)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('128', 'SECTION OFFICER (ACCOUNTS)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('129', 'SECTION OFFICER (ASSEMBLY BUSINNES)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('130', 'SECTION OFFICER (PRIMARY)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('131', 'SECTION OFFICER SCHOOLS (MALE)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('132', 'SECTION OFFICER SCHOOLS (FEMALE)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('133', 'PS TO SECRETARY OFFICE', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('134', 'DS LEGAL', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('135', 'PS TO MBR-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('136', 'PS To MBR-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('137', 'Assistant Secretary (Lit-I)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('138', 'Assistant Secretary (Lit-II)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('139', 'Senior Clerk', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('140', 'special assistant to cm', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('141', 'PSDP', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('142', 'Additional Secretary-I, Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('143', 'Deputy Secretary (Estate),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('144', 'Section Officer (Estate), Adminstration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('145', 'Section Officer (Trans),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('146', 'Section Officer (Imp.),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('147', 'Director Protocol, Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('148', 'MONITORING OFFICER-I', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('149', 'MONITORING OFFICER-II', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('150', 'MONITORING OFFICER-III', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('151', 'Section Officer (Cabinet),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('152', 'Supdt (CBA), Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('153', 'Supt(Admin),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('154', 'Supt (Benevolent),Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('155', 'Additional Secretary-II,Administration', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('156', 'PMS Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('157', 'Project Director', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('158', 'Chief', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('159', 'Data base admin', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('160', 'Superindent', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('161', 'Director General', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('162', 'PLANNING OFFICER-IV', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('163', 'provincial coordinator pftb', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('164', 'SECTION OFFICER GENERAL', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('165', 'SECTION OFFICER PRIMARY', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('166', 'Superintendent', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('167', 'D F O', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('168', 'Cheif Conservator WL', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('169', 'Statistical Officer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('170', 'Web Developer', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('171', 'Focal Person HEMIS', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('172', 'Section Officer (Arms)', '1');
INSERT INTO `designation` (`iddesignation`, `designation`, `status`) VALUES ('173', 'PS  to Home Minister', '1');


#
# TABLE STRUCTURE FOR: dispatch_files
#

DROP TABLE IF EXISTS `dispatch_files`;

CREATE TABLE `dispatch_files` (
  `dispatch_id` int(11) NOT NULL AUTO_INCREMENT,
  `dispatch_date` date DEFAULT NULL,
  `iddepartment` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `main_id` int(11) DEFAULT NULL,
  `main_log_id` int(11) DEFAULT NULL,
  `file_no` varchar(30) NOT NULL,
  `file_name` varchar(30) NOT NULL,
  `filed_by` varchar(15) NOT NULL,
  `filed_date` date NOT NULL,
  PRIMARY KEY (`dispatch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `dispatch_files` (`dispatch_id`, `dispatch_date`, `iddepartment`, `user_id`, `main_id`, `main_log_id`, `file_no`, `file_name`, `filed_by`, `filed_date`) VALUES ('1', '2019-03-18', NULL, '1', '1', '2', 'mma/adm/rg/m-36/vol2', 'mps common fund', '1', '2019-03-18');
INSERT INTO `dispatch_files` (`dispatch_id`, `dispatch_date`, `iddepartment`, `user_id`, `main_id`, `main_log_id`, `file_no`, `file_name`, `filed_by`, `filed_date`) VALUES ('2', '2019-03-18', NULL, '1', '2', '4', 'MMA/ADM/RG/A-1', 'ADVANCE TO PURCHASE ', '1', '2019-03-18');
INSERT INTO `dispatch_files` (`dispatch_id`, `dispatch_date`, `iddepartment`, `user_id`, `main_id`, `main_log_id`, `file_no`, `file_name`, `filed_by`, `filed_date`) VALUES ('3', '2020-05-05', NULL, '1', '6', '9', 'MMA/ADM/RG/A-1', 'ADVANCE TO PURCHASE ', '1', '2020-05-05');
INSERT INTO `dispatch_files` (`dispatch_id`, `dispatch_date`, `iddepartment`, `user_id`, `main_id`, `main_log_id`, `file_no`, `file_name`, `filed_by`, `filed_date`) VALUES ('4', '2020-05-08', NULL, '1', '7', '11', 'MMA/ADM/RG/C-70', 'CONSTRUCTION OF 3-UN', '1', '2020-05-08');


#
# TABLE STRUCTURE FOR: doc_type
#

DROP TABLE IF EXISTS `doc_type`;

CREATE TABLE `doc_type` (
  `doc_id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_type` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('1', 'Brief');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('2', 'Directives');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('3', 'File');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('4', 'Letter');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('5', 'Meeting Minutes');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('6', 'Note For Secy:');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('7', 'others');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('8', 'Summary For CM');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('9', 'Working Paper');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('11', 'Note For CS');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('12', 'Note For Minister');
INSERT INTO `doc_type` (`doc_id`, `doc_type`) VALUES ('13', 'Note For ACS');


#
# TABLE STRUCTURE FOR: employee
#

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `idemployee` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `empname` varchar(45) NOT NULL DEFAULT '',
  `empemail` varchar(45) NOT NULL DEFAULT '',
  `iddepartment` int(10) unsigned NOT NULL DEFAULT '0',
  `idsection` int(10) unsigned NOT NULL DEFAULT '0',
  `iddesignation` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `EMP_PIC` varchar(100) NOT NULL,
  PRIMARY KEY (`idemployee`)
) ENGINE=MyISAM AUTO_INCREMENT=552 DEFAULT CHARSET=utf8;

INSERT INTO `employee` (`idemployee`, `empname`, `empemail`, `iddepartment`, `idsection`, `iddesignation`, `status`, `EMP_PIC`) VALUES ('547', 'admin', 'admin@email.com', '0', '0', '0', '1', '');
INSERT INTO `employee` (`idemployee`, `empname`, `empemail`, `iddepartment`, `idsection`, `iddesignation`, `status`, `EMP_PIC`) VALUES ('548', 'ERIC ', 'bblyrix@gmail.com`', '0', '0', '0', '1', 'uploads/images/no_avatar.jpg');
INSERT INTO `employee` (`idemployee`, `empname`, `empemail`, `iddepartment`, `idsection`, `iddesignation`, `status`, `EMP_PIC`) VALUES ('549', 'Junior', 'junior@yahoo.com', '0', '0', '0', '1', 'uploads/images/no_avatar.jpg');
INSERT INTO `employee` (`idemployee`, `empname`, `empemail`, `iddepartment`, `idsection`, `iddesignation`, `status`, `EMP_PIC`) VALUES ('550', 'Lamere', 'lam@yahoo.com', '0', '0', '0', '1', 'uploads/images/img.jpg');
INSERT INTO `employee` (`idemployee`, `empname`, `empemail`, `iddepartment`, `idsection`, `iddesignation`, `status`, `EMP_PIC`) VALUES ('551', 'Vora', 'vorsa@yahoo.com', '0', '0', '0', '1', 'uploads/images/no_avatar.jpg');


#
# TABLE STRUCTURE FOR: employee_profile
#

DROP TABLE IF EXISTS `employee_profile`;

CREATE TABLE `employee_profile` (
  `EMP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `EMP_NAME` varchar(300) NOT NULL,
  `EMP_ADDRESS` varchar(300) NOT NULL,
  `EMP_PHONE` varchar(300) NOT NULL,
  `EMP_CELL` varchar(300) NOT NULL,
  `EMP_EMAIL` varchar(300) NOT NULL,
  `EMP_PIC` varchar(300) NOT NULL,
  `EMP_GENDER` varchar(11) NOT NULL,
  `EMP_DATE` date NOT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_USERID` int(11) DEFAULT NULL,
  `UPDATED_DATE` date DEFAULT NULL,
  `UPDATED_USERID` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMP_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `employee_profile` (`EMP_ID`, `EMP_NAME`, `EMP_ADDRESS`, `EMP_PHONE`, `EMP_CELL`, `EMP_EMAIL`, `EMP_PIC`, `EMP_GENDER`, `EMP_DATE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('1', 'Dennis Darko', 'Ambl 88 Santasi', '0247666618', '', 'dennisdarko1990@gmail.com', 'uploads/images/IMG_0028.JPG', 'MALE', '2018-12-12', '2018-12-12', '1', NULL, NULL);
INSERT INTO `employee_profile` (`EMP_ID`, `EMP_NAME`, `EMP_ADDRESS`, `EMP_PHONE`, `EMP_CELL`, `EMP_EMAIL`, `EMP_PIC`, `EMP_GENDER`, `EMP_DATE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('2', 'Edna Majambe', 'box ry 45', '0247666618', '0247666618', 'ednamajambe@gmail.com', 'uploads/images/g.jpg', 'FE-MALE', '2018-12-19', '2018-12-19', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: file_movement
#

DROP TABLE IF EXISTS `file_movement`;

CREATE TABLE `file_movement` (
  `file_m_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_collected` date DEFAULT NULL,
  `idemployee` int(11) DEFAULT NULL,
  `iddepartment` int(11) DEFAULT NULL,
  `file_no` varchar(25) DEFAULT NULL,
  `name_of_file` varchar(50) DEFAULT NULL,
  `number_of_letters` int(11) DEFAULT NULL,
  `remarks` text,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `returned_date` date DEFAULT NULL,
  `returned_by` varchar(11) DEFAULT NULL,
  `returned_letters` int(11) DEFAULT '0',
  `returned_department` int(11) DEFAULT NULL,
  `returned_status` varchar(11) DEFAULT NULL,
  `job_title` varchar(20) NOT NULL,
  `telephone_no` varchar(20) NOT NULL,
  `returning_days` int(20) NOT NULL,
  `file_given_to` varchar(20) NOT NULL,
  `returning_job_title` varchar(20) NOT NULL,
  `returning_tele_no` varchar(20) NOT NULL,
  PRIMARY KEY (`file_m_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `file_movement` (`file_m_id`, `date_collected`, `idemployee`, `iddepartment`, `file_no`, `name_of_file`, `number_of_letters`, `remarks`, `status`, `user_id`, `file_id`, `returned_date`, `returned_by`, `returned_letters`, `returned_department`, `returned_status`, `job_title`, `telephone_no`, `returning_days`, `file_given_to`, `returning_job_title`, `returning_tele_no`) VALUES ('1', '2020-05-05', NULL, NULL, 'MMA/ADM/RG/A-19', 'AGRIC SUB-COMMITTEE', '20', 'This file was issued to Okpoigonnor', '1', '1', NULL, NULL, NULL, '0', NULL, 'Returned', 'IT CLERK', '0272185090', '5', 'Ogua Ahmed', '', '');
INSERT INTO `file_movement` (`file_m_id`, `date_collected`, `idemployee`, `iddepartment`, `file_no`, `name_of_file`, `number_of_letters`, `remarks`, `status`, `user_id`, `file_id`, `returned_date`, `returned_by`, `returned_letters`, `returned_department`, `returned_status`, `job_title`, `telephone_no`, `returning_days`, `file_given_to`, `returning_job_title`, `returning_tele_no`) VALUES ('2', NULL, NULL, NULL, 'MMA/ADM/RG/A-19', 'AGRIC SUB-COMMITTEE', '20', NULL, '0', '1', '0', '2020-05-05', NULL, '20', NULL, NULL, '', '', '0', '', '', '');
INSERT INTO `file_movement` (`file_m_id`, `date_collected`, `idemployee`, `iddepartment`, `file_no`, `name_of_file`, `number_of_letters`, `remarks`, `status`, `user_id`, `file_id`, `returned_date`, `returned_by`, `returned_letters`, `returned_department`, `returned_status`, `job_title`, `telephone_no`, `returning_days`, `file_given_to`, `returning_job_title`, `returning_tele_no`) VALUES ('3', '2020-05-05', NULL, NULL, 'MMA/ADM/RG/A-2', 'ADVANCE GENERAL', '20', 'Must be returned earlier', '1', '1', NULL, NULL, NULL, '0', NULL, 'Unreturned', 'IT CLERK', '0272185090', '2', 'Ogua Ahmed', '', '');


#
# TABLE STRUCTURE FOR: file_naming
#

DROP TABLE IF EXISTS `file_naming`;

CREATE TABLE `file_naming` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(20) NOT NULL,
  `file_no` varchar(20) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=latin1;

INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('2', 'ADVANCE TO PURCHASE ', 'MMA/ADM/RG/A-1');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('3', 'ADVANCE GENERAL', 'MMA/ADM/RG/A-2');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('4', 'ALLOWANCES GENERAL', 'MMA/ADM/RG/A-3');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('5', 'ADMINISTRATION OF ST', 'MMA/ADM/RG/A-4');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('6', 'ASANTEMAN DEVELOPMEN', 'MMA/ADM/RG/A-5');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('7', 'ASSEMBLY VEHICLES', 'MMA/ADM/RG/A-6');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('8', 'ALLOCCATION OF CEMEN', 'MMA/ADM/RG/A-7');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('9', 'ADMINISTRATION ANNUA', 'MMA/ADM/RG/A-8');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('10', 'ANNUAL PROGRESS REPO', 'MMA/ADM/RG/A-9');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('11', 'AWARD OF CONTRACT', 'MMA/ADM/RG/A-10');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('12', 'AUDIT REPORT', 'MMA/ADM/RG/A-12');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('13', 'AGRICULTURE GENERAL', 'MMA/ADM/RG/A-14');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('15', 'ADMINISTRATIVE OFFIC', 'MMA/ADM/RG/A-16');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('16', 'AUDIT COMMITTEE', 'MMA/ADM/RG/A-17');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('17', 'AGRIC SUB-COMMITTEE', 'MMA/ADM/RG/A-19');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('18', 'ALLOCATION OF PLOT G', 'MMA/ADM/RG/A-20');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('19', 'ALLOCATION OF QUARTE', 'MMA/ADM/RG/A-21');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('20', 'ACQUISITION OF LAND ', 'MMA/ADM/RG/A-22');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('21', 'ADIDWAN ZONAL COUNCI', 'MMA/ADM/RG/A-23');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('22', 'AMANIAMPONG SEC. SCH', 'MMA/ADM/RG/A-25');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('23', 'ANNUAL REPORT', 'MMA/ADM/RG/A-26');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('24', 'ASSOCIATION AND UNIO', 'MMA/ADM/RG/A-27');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('25', 'ATTACHMENT GENERAL', 'MMA/ADM/RG/A-28');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('26', 'ALLOCATION OF MAMPON', 'MMA/ADM/RG/A-29');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('27', 'AUCTION', 'MMA/ADM/RG/A-31');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('28', 'ASSOCIATION OF CIVIL', 'MMA/ADM/RG/A-32');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('29', 'ASSOCIATION OF PERSO', 'MMA/ADM/RG/A-33');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('30', 'ASSEMBLY MOTOR BYCIC', 'MMA/ADM/RG/A-34');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('31', 'AFRICAN PEER REVIEW ', 'MMA/ADM/RG/A-35');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('32', 'APPLICATION FOR FINA', 'MMA/ADM/RG/A-37');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('33', 'ARTISANS', 'MMA/ADM/RG/A-38');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('34', 'ASSEMBLY BUILDINGS', 'MMA/ADM/RG/A-39');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('35', 'ANNUAL ACCOUNTS', 'MMA/ADM/RG/A-40');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('36', 'ASSEMBLY VEHICLE-NIS', 'MMA/ADM/RG/A-43');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('37', 'ASSEMBLY VEHICLE-NIS', 'MMA/ADM/RG/A-44');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('38', 'ASSEMBLY VEHICLE TOY', 'MMA/ADM/RG/A-45');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('39', 'ASSEMBLY VEHICLE TOY', 'MMA/ADM/RG/A-46');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('40', 'ASSEMBLY VEHICLE-ISU', 'MMA/ADM/RG/A-47');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('41', 'ASSEMBLY VEHICLE-ZET', 'MMA/ADM/RG/A-48');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('42', 'ASSEMBLY VEHICLE-PAY', 'MMA/ADM/RG/A-49');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('43', 'ASSEMBLY VEHICLE-TAT', 'MMA/ADM/RG/A-50');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('44', 'ASSEMBLY VEHICLE- RE', 'MMA/ADM/RG/A-51');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('45', 'ASSEMBLY VEHICLE - B', 'MMA/ADM/RG/A-52');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('46', 'ASSEMBLY VEHICLE - G', 'MMA/ADM/RG/A-53');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('47', 'ASSEMBLY VEHICLE BMC', 'MMA/ADM/RG/A-56');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('48', 'ASSEMBLY VEHICLE FOR', 'MMA/ADM/RG/A-57');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('49', 'ASSEMBLY VEHICLE HOW', 'MMA/ADM/RG/A-58');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('50', 'AFRICAN GLOBAL SISTE', 'MMA/ADM/RG/A-59');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('51', 'ACQUISITION OF ASOKW', 'MMA/ADM/RG/A-60');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('52', 'ACQUIRED LAND FOR MM', 'MMA/ADM/RG/A-62');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('53', 'ANNIVERSARY CELEBRAT', 'MMA/ADM/RG/A-63');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('54', 'ASSEMBLY VEHICLE REP', 'MMA/ADM/RG/A-64');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('55', 'ALLOCATION OF PLOT -', 'MMA/ADM/RG/A-65');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('56', 'AUTION PLAN FOR OTHE', 'MMA/ADM/RG/A-61');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('57', 'ANNUAL STATEMENT OF ', 'MMA/ADM/RG/A-66');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('58', 'ANNUAL ACTION PLAN A', 'MMA/ADM/RG/A-67');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('59', 'APPLICATION FOR PERM', 'MMA/ADM/RG/A-68');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('60', 'ASSEMBLY VEHICLE-NAV', 'MMA/ADM/RG/A-69');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('61', 'AD-HOC COMMITTEE', 'MMA/ADM/RG/A-70');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('62', 'AGREEMENT GENERAL', 'MMA/ADM/RG/A-71');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('63', 'ARCHITECTURAL DESIGN', 'MMA/ADM/RG/A-72');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('64', 'APPOINTMENT/RECRUITM', 'MMA/ADM/RG/A-74');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('65', 'BASIC RATE', 'MMA/ADM/RG/B-1');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('66', 'BUDGET COMMITTEE MEE', 'MMA/ADM/RG/B-2');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('67', 'BENIM ZONAL COUNCIL', 'MMA/ADM/RG/B-3');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('68', 'BUDGET COMMITTEE', 'MMA/ADM/RG/B-4');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('69', 'BUILDING/INSPECTORAT', 'MMA/ADM/RG/B-6');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('70', 'BYE-LAWS', 'MMA/ADM/RG/B-7');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('71', 'BANK SIGNATORIES GEN', 'MMA/ADM/RG/B-8');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('72', 'BOARD OF SURVEY ', 'MMA/ADM/RG/B-9');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('73', 'BUSINESS ADVISORY CE', 'MMA/ADM/RG/B-10');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('74', 'BUDGET DECENTRALISED', 'MMA/ADM/RG/B-11');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('75', 'CONTRACT GENERAL', 'MMA/ADM/RG/C-1');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('76', 'CONTRACT AGREEMENT', 'MMA/ADM/RG/C-2');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('77', 'COMMUNITY INITIATED ', 'MMA/ADM/RG/C-3');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('78', 'COMMISSION OF ENQUIR', 'MMA/ADM/RG/C-5');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('79', 'CONTROLLER AND ACCOU', 'MMA/ADM/RG/C-6');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('80', 'CHIEFTANCY-AFFAIRS', 'MMA/ADM/RG/C-15');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('81', 'CEMETERIES', 'MMA/ADM/RG/C-16');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('82', 'CHRISMAS GREETING CA', 'MMA/ADM/RG/C-18');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('83', 'CENSUS', 'MMA/ADM/RG/C-19');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('84', 'CENTRE FOR CIVIC EDU', 'MMA/ADM/RG/C-20');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('85', 'COMMISSIONER FOR OAT', 'MMA/ADM/RG/C-21');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('86', 'COURT CASES', 'MMA/ADM/RG/C-22');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('87', 'COMMUNITY CENTERS', 'MMA/ADM/RG/C-23');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('88', 'CIVIL SERVICE EXAMIN', 'MMA/ADM/RG/C-24');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('89', 'CINEMA OPERATION', 'MMA/ADM/RG/C-25');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('90', 'CIVIL SERVANTS PERFO', 'MMA/ADM/RG/C-26');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('91', 'CONFIDENTIAL MATTERS', 'MMA/ADM/RG/C-27');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('92', 'CIVIL SERVICE LADIES', 'MMA/ADM/RG/C-29');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('93', 'CONSTITUTION REVIEW ', 'MMA/ADM/RG/C-30');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('94', 'CONSTITUTION OF WARE', 'MMA/ADM/RG/C-31');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('95', 'CREDIT UNION', 'MMA/ADM/RG/C-32');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('96', 'CONSTRUCTION OF ZONA', 'MMA/ADM/RG/C-34');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('97', 'CONST. OF 6-UNIT CLA', 'MMA/ADM/RG/C-35');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('98', 'CONST. AND COMPLETIO', 'MMA/ADM/RG/C-36');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('99', 'CONST. OF NO.3-UNIT ', 'MMA/ADM/RG/C-37');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('100', 'CONST. OF NO.3 UNIT ', 'MMA/ADM/RG/C-38');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('101', 'COUNCIL OF STATE', 'MMA/ADM/RG/C-39');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('102', 'CURRICULUM VITAE - A', 'MMA/ADM/RG/C-40');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('103', 'CONST. OF CLASSROOM ', 'MMA/ADM/RG/C-41');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('104', 'CONST. OF 1NO. 16 SE', 'MMA/ADM/RG/C-42');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('105', 'CONST. OF 1NO.3-UNIT', 'MMA/ADM/RG/C-43');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('106', 'CONST.OF 12-SEATER A', 'MMA/ADM/RG/C-44');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('107', 'CONST. OF 16-SEATER ', 'MMA/ADM/RG/C-45');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('108', 'CONST. OF 2-UNIT MED', 'MMA/ADM/RG/C-46');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('109', 'CONST. AND COMP. OF ', 'MMA/ADM/RG/C-47');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('110', 'CONST. OF METAL FENC', 'MMA/ADM/RG/C-48');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('111', 'CONTRUCTION AND COMP', 'MMA/ADM/RG/C-49');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('112', 'COMMISSION ON HUMAN ', 'MMA/ADM/RG/C-50');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('113', 'CONSTRUCTION AQUA PR', 'MMA/ADM/RG/C-52');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('114', 'CONST.OF 3-UNIT CLAS', 'MMA/ADM/RG/C-53');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('115', 'CONST.OF 1NO.3-UNIT ', 'MMA/ADM/RG/C-54');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('116', 'CONST. OF CHPS COMPO', 'MMA/ADM/RG/C-55');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('117', 'CONST. OF 1 NO.16 SE', 'MMA/ADM/RG/C-56');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('118', 'CONST. OF 6-UNIT CLA', 'MMA/ADM/RG/C-57');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('119', 'CONST. OF 1NO.3-UNII', 'MMA/ADM/RG/C-58');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('120', 'CONST. OF 1NO.16 SEA', 'MMA/ADM/RG/C-59');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('121', 'CONST. OF 1NO.12-SEA', 'MMA/ADM/RG/C-60');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('122', 'CONST. OF BEDSITER-S', 'MMA/ADM/RG/C-61');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('123', 'CONST. OF3/12COMM DI', 'MMA/ADM/RG/C-62');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('124', 'CONST. OF CLASSROOM ', 'MMA/ADM/RG/C-63');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('125', 'CONST. 1NO.3-UNIT CL', 'MMA/ADM/RG/C-65');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('126', 'COMMISSION OF ENQUIR', 'MMA/ADM/RG/C-67');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('127', 'CONSTRUCTION OF TWO ', 'MMA/ADM/RG/C-9');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('128', 'CONSTRUCTION OF 3-UN', 'MMA/ADM/RG/C-70');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('129', 'CAPACITY SUPPORT FUN', 'MMA/ADM/RG/C-71');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('130', 'CONSTRUCTION OF 1NO.', 'MMA/ADM/RG/C-72');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('131', 'CONST. OF 1NO.12-SEA', 'MMA/ADM/RG/SF.2/V0L.');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('132', 'CONST. OF CHPS COMPO', 'MMA/ADM/RG/SF.1/V0L.');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('133', 'CONST. OF 1NO. 12-SE', 'MMA/ADM/RG/SF.3/V0L.');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('134', 'SUPPLY OF FURNITURE ', 'MMA/ADM/RG/SF.4/V0L.');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('135', 'CONSTRUCTION OF 3-UN', 'MMA/ADM/RG/SF.5/V0L.');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('136', 'CONSTRUCTION OF 2 ST', 'MMA/ADM/RG/SF./A-10S');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('137', 'CONST. 1NO.2UNIT LOC', 'MMA/ADM/RG/SF./A-1/S');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('138', 'CONST. OF 6 UNIT CLA', 'MMA/ADM/RG/SF./A-1SF');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('139', 'CONST. BOREHOLES-AFR', 'MMA/ADM/RG/SF./A-10/');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('140', 'CONST. OF CLASSROOM-', 'MMA/ADM/RG/SF./A-10/');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('141', 'CERTIFICATE - GENERA', 'MMA/ADM/RG/SF./C-86/');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('142', 'COMPLETION OF 22 LOC', 'MMA/ADM/RG/SF./C-87/');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('143', 'CONSTRUCTION CHPS CO', 'A-10/SF-9');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('144', 'CONST. OF POLICE POL', 'A-10/SF-10');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('145', 'CONST. OF 6-UNIT CLA', 'A-10/SF-11');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('146', 'CONST. OF 4 UNIT CLA', 'A-10/SF-15');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('147', 'COMPLETIONG OF CHPS ', 'A-10/SF-15');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('148', 'CONST. OF CHPS COMPO', 'A-10/SF-16');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('149', 'CLEAN AND GREEN CAMP', 'C-93');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('150', 'CONFIRMATION OF MMD ', 'C-94');
INSERT INTO `file_naming` (`file_id`, `file_name`, `file_no`) VALUES ('151', 'CHAUCER LIMITED', 'C-95');


#
# TABLE STRUCTURE FOR: filestatus
#

DROP TABLE IF EXISTS `filestatus`;

CREATE TABLE `filestatus` (
  `idfilestatus` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filestatus` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idfilestatus`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('1', 'Not Sent', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('2', 'Disposed off', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('3', 'Endorsed', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('5', 'Forwarded', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('6', 'Pending', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('8', 'Returned', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('9', 'Sent', '1');
INSERT INTO `filestatus` (`idfilestatus`, `filestatus`, `status`) VALUES ('10', 'Dispatched', '1');


#
# TABLE STRUCTURE FOR: filetype
#

DROP TABLE IF EXISTS `filetype`;

CREATE TABLE `filetype` (
  `idfiletype` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `filetype` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idfiletype`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `filetype` (`idfiletype`, `filetype`, `status`) VALUES ('14', 'Report', '1');
INSERT INTO `filetype` (`idfiletype`, `filetype`, `status`) VALUES ('15', 'Memo', '1');
INSERT INTO `filetype` (`idfiletype`, `filetype`, `status`) VALUES ('16', 'Letter', '1');
INSERT INTO `filetype` (`idfiletype`, `filetype`, `status`) VALUES ('17', 'Speech', '1');
INSERT INTO `filetype` (`idfiletype`, `filetype`, `status`) VALUES ('18', 'Minute', '1');


#
# TABLE STRUCTURE FOR: flag
#

DROP TABLE IF EXISTS `flag`;

CREATE TABLE `flag` (
  `idflag` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `flag` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idflag`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `flag` (`idflag`, `flag`, `status`) VALUES ('1', 'Very Confidential', '1');
INSERT INTO `flag` (`idflag`, `flag`, `status`) VALUES ('2', 'Confidential', '1');
INSERT INTO `flag` (`idflag`, `flag`, `status`) VALUES ('3', 'Normal', '1');
INSERT INTO `flag` (`idflag`, `flag`, `status`) VALUES ('4', 'Urgent', '1');
INSERT INTO `flag` (`idflag`, `flag`, `status`) VALUES ('5', 'Immediate', '1');


#
# TABLE STRUCTURE FOR: issue
#

DROP TABLE IF EXISTS `issue`;

CREATE TABLE `issue` (
  `idissue` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `barcode` varchar(45) NOT NULL DEFAULT '',
  `fileno` varchar(45) NOT NULL DEFAULT '',
  `dairyno` varchar(45) NOT NULL DEFAULT '',
  `subject` text,
  `remarks` text,
  `idfiletype` int(10) unsigned NOT NULL DEFAULT '0',
  `idfilestatus` int(10) unsigned NOT NULL DEFAULT '0',
  `idflag` int(10) unsigned NOT NULL DEFAULT '0',
  `idvolume` int(10) unsigned NOT NULL DEFAULT '0',
  `idsource` int(10) unsigned NOT NULL DEFAULT '0',
  `fromdept` int(10) unsigned NOT NULL DEFAULT '0',
  `fromsection` int(10) unsigned NOT NULL DEFAULT '0',
  `todept` int(10) unsigned NOT NULL DEFAULT '0',
  `tosection` int(10) unsigned NOT NULL DEFAULT '0',
  `scan` varchar(100) DEFAULT NULL,
  `datetime` date DEFAULT NULL,
  `idusers` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`idissue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: main
#

DROP TABLE IF EXISTS `main`;

CREATE TABLE `main` (
  `main_id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_id` int(11) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `scan_image` varchar(100) DEFAULT NULL,
  `from` varchar(50) DEFAULT NULL,
  `for` varchar(100) DEFAULT NULL,
  `date_received` date DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `file_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date_issue` date DEFAULT NULL,
  `flag_id` int(11) DEFAULT NULL,
  `iddesignation` int(11) DEFAULT NULL,
  `reference_no` varchar(100) DEFAULT NULL,
  `remarks` text,
  `case_no` varchar(100) DEFAULT NULL,
  `registry_no` varchar(30) DEFAULT NULL,
  `date_on_letter` date NOT NULL,
  `forwarded` varchar(20) NOT NULL,
  `cell_no` varchar(15) NOT NULL,
  `person_name` varchar(25) NOT NULL,
  `iddepartment` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `person_contact` varchar(20) NOT NULL,
  PRIMARY KEY (`main_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `main` (`main_id`, `doc_id`, `subject`, `scan_image`, `from`, `for`, `date_received`, `status`, `file_id`, `user_id`, `date_issue`, `flag_id`, `iddesignation`, `reference_no`, `remarks`, `case_no`, `registry_no`, `date_on_letter`, `forwarded`, `cell_no`, `person_name`, `iddepartment`, `idemployee`, `person_contact`) VALUES ('3', '14', 'Mail Received', 'uploads/created_files/Evalution_Form.pdf', 'Lamere Junior', NULL, '2019-03-28', '9', NULL, '3', '2019-03-23', '3', NULL, '34772', ' No Remarks', NULL, '2303191', '2019-03-27', 'Forwarded', '02722185090', 'Ogua Ahmed', '0', '0', '02721850900');
INSERT INTO `main` (`main_id`, `doc_id`, `subject`, `scan_image`, `from`, `for`, `date_received`, `status`, `file_id`, `user_id`, `date_issue`, `flag_id`, `iddesignation`, `reference_no`, `remarks`, `case_no`, `registry_no`, `date_on_letter`, `forwarded`, `cell_no`, `person_name`, `iddepartment`, `idemployee`, `person_contact`) VALUES ('4', '14', 'fgfgfg', NULL, 'dfffdfd', NULL, '2020-05-20', '9', NULL, '1', '2020-05-05', '1', NULL, 'gfgfg', ' fgfgf', NULL, '0505204', '2020-05-21', 'Forwarded', '44444444444', 'fgfg', '0', '0', '8888888888');
INSERT INTO `main` (`main_id`, `doc_id`, `subject`, `scan_image`, `from`, `for`, `date_received`, `status`, `file_id`, `user_id`, `date_issue`, `flag_id`, `iddesignation`, `reference_no`, `remarks`, `case_no`, `registry_no`, `date_on_letter`, `forwarded`, `cell_no`, `person_name`, `iddepartment`, `idemployee`, `person_contact`) VALUES ('5', '15', 'Home Live we live', NULL, 'Ahmed Ahia', NULL, '2020-05-13', '9', NULL, '1', '2020-05-05', '0', NULL, 'Ref237838', ' THis is a file', NULL, '0505205', '2020-04-30', 'Forwarded', '0272185090', 'Ogua Lamere', '0', '0', '0272185090');
INSERT INTO `main` (`main_id`, `doc_id`, `subject`, `scan_image`, `from`, `for`, `date_received`, `status`, `file_id`, `user_id`, `date_issue`, `flag_id`, `iddesignation`, `reference_no`, `remarks`, `case_no`, `registry_no`, `date_on_letter`, `forwarded`, `cell_no`, `person_name`, `iddepartment`, `idemployee`, `person_contact`) VALUES ('6', '16', 'This is false', 'uploads/created_files/The TotalSchool Proposal_2.pdf', 'Ahmed Ahia', NULL, '2020-05-12', '3', NULL, '1', '2020-05-05', '3', NULL, 'Ref2378385', 'This is good. ', NULL, '0505206', '2020-05-20', 'Received Back', '0272185090', 'Ogua Lamere', '0', '0', '0272185090');
INSERT INTO `main` (`main_id`, `doc_id`, `subject`, `scan_image`, `from`, `for`, `date_received`, `status`, `file_id`, `user_id`, `date_issue`, `flag_id`, `iddesignation`, `reference_no`, `remarks`, `case_no`, `registry_no`, `date_on_letter`, `forwarded`, `cell_no`, `person_name`, `iddepartment`, `idemployee`, `person_contact`) VALUES ('7', '15', ' This is my mail', 'uploads/created_files/10_DESIGN.pdf', 'Ahmed Ahia', NULL, '2020-05-08', '3', NULL, '1', '2020-05-08', '3', NULL, 'Ref237830', ' This mail is not urgent', NULL, '0805207', '2020-05-21', 'Received Back', '0272185090', 'Ogua Lamere', '0', '0', '0272185090');


#
# TABLE STRUCTURE FOR: main_log
#

DROP TABLE IF EXISTS `main_log`;

CREATE TABLE `main_log` (
  `main_log_id` int(11) NOT NULL AUTO_INCREMENT,
  `main_id` int(11) DEFAULT NULL,
  `from` varchar(100) DEFAULT NULL,
  `for` varchar(100) DEFAULT NULL,
  `date_of_sending` date DEFAULT NULL,
  `remarks` varchar(200) DEFAULT NULL,
  `ml_status` int(1) NOT NULL,
  `iddesignation` int(11) NOT NULL,
  `date_of_received` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `dispatched` int(1) NOT NULL,
  `image` varchar(100) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `returned_by` varchar(20) NOT NULL,
  `returned_contact` varchar(20) NOT NULL,
  `received_by` varchar(20) NOT NULL,
  `received_contact` varchar(20) NOT NULL,
  `print` int(1) NOT NULL,
  `returned_date` date NOT NULL,
  `p_id` int(11) NOT NULL,
  `received_job_title` varchar(20) NOT NULL,
  `r_status` varchar(11) NOT NULL,
  `returned_job_title` varchar(20) NOT NULL,
  PRIMARY KEY (`main_log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('5', '3', NULL, NULL, NULL, NULL, '0', '0', '2019-03-23', '0', '0', '', '0', '', '', '', '', '0', '0000-00-00', '1', '', '', '');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('6', '4', NULL, NULL, NULL, NULL, '0', '0', '2020-05-05', '0', '0', '', '0', '', '', '', '', '0', '0000-00-00', '2', '', '', '');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('7', '5', NULL, NULL, NULL, NULL, '0', '0', '2020-05-05', '0', '0', 'uploads/printLetters/Admission Voucher.pdf', '0', '', '', 'Ahmed Ahia', '', '0', '0000-00-00', '3', 'Clerk', 'forwarded', '');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('8', '6', NULL, NULL, NULL, NULL, '8', '0', '2020-05-05', '0', '0', 'uploads/printLetters/Admission Voucher.pdf', '0', '', '', 'Ahmed Ahia', '', '0', '0000-00-00', '3', 'Clerk', 'forwarded', '');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('9', '6', 'Ahmed Ahia', NULL, '2020-05-05', NULL, '1', '0', '0000-00-00', '1', '1', 'uploads/returned_files/Admission Voucher.pdf', '0', 'Kwame Eugene', '', '', '', '0', '2020-05-05', '0', '', 'forwarded', 'IT CLERK');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('10', '7', NULL, NULL, NULL, NULL, '8', '0', '2020-05-08', '0', '0', 'uploads/printLetters/fwrds.pdf', '0', '', '', 'Akeyaa eko', '', '0', '0000-00-00', '4', 'Supreme Clerk', 'forwarded', '');
INSERT INTO `main_log` (`main_log_id`, `main_id`, `from`, `for`, `date_of_sending`, `remarks`, `ml_status`, `iddesignation`, `date_of_received`, `user_id`, `dispatched`, `image`, `idemployee`, `returned_by`, `returned_contact`, `received_by`, `received_contact`, `print`, `returned_date`, `p_id`, `received_job_title`, `r_status`, `returned_job_title`) VALUES ('11', '7', 'Ahmed Ahia', NULL, '2020-05-08', NULL, '1', '0', '0000-00-00', '1', '1', 'uploads/returned_files/fwrds.pdf', '0', 'Kwame Osei', '', '', '', '0', '2020-05-08', '0', '', '', 'Security Officer');


#
# TABLE STRUCTURE FOR: outgoing_mails
#

DROP TABLE IF EXISTS `outgoing_mails`;

CREATE TABLE `outgoing_mails` (
  `om_id` int(11) NOT NULL AUTO_INCREMENT,
  `dispatch_date` date DEFAULT NULL,
  `registry_number` int(11) DEFAULT NULL,
  `sent_to` varchar(200) DEFAULT NULL,
  `date_of_letter` date DEFAULT NULL,
  `reference_number` varchar(20) DEFAULT NULL,
  `subject` varchar(100) DEFAULT NULL,
  `sending_dept` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `brought_by` varchar(100) DEFAULT NULL,
  `cell_no` varchar(20) DEFAULT NULL,
  `scan_copy` varchar(100) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `remarks` text,
  `scan_copy_printed` varchar(100) NOT NULL,
  PRIMARY KEY (`om_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `outgoing_mails` (`om_id`, `dispatch_date`, `registry_number`, `sent_to`, `date_of_letter`, `reference_number`, `subject`, `sending_dept`, `position`, `brought_by`, `cell_no`, `scan_copy`, `status`, `remarks`, `scan_copy_printed`) VALUES ('2', '2020-05-08', NULL, 'ogua', '2020-05-15', 'ref5664', 'hey you', 'IT', 'Nabco', 'Kwame Eugene', '0000000000', 'uploads/outgoing_mails/fwrds.pdf', '1', ' gfg', '');
INSERT INTO `outgoing_mails` (`om_id`, `dispatch_date`, `registry_number`, `sent_to`, `date_of_letter`, `reference_number`, `subject`, `sending_dept`, `position`, `brought_by`, `cell_no`, `scan_copy`, `status`, `remarks`, `scan_copy_printed`) VALUES ('3', '2020-05-08', NULL, 'human rresource manager (KMA),Accounting Department (MMA)', '2020-05-20', 'ref5667878888', 'this is them', 'HR', 'Human resoutrce manager, Mampong Assembly ', 'AGNATIUS SANINUI', '0545819929', 'uploads/outgoing_mails/fwrds.pdf', '1', ' tgere is my remarks', '');


#
# TABLE STRUCTURE FOR: receive
#

DROP TABLE IF EXISTS `receive`;

CREATE TABLE `receive` (
  `idreceive` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idissue` int(10) unsigned NOT NULL DEFAULT '0',
  `received` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `datetime` datetime NOT NULL,
  `idusers` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(45) NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idreceive`),
  KEY `idissue` (`idissue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `idsection` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `section` varchar(45) NOT NULL DEFAULT '',
  `iddepartment` int(10) unsigned NOT NULL DEFAULT '0',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idsection`)
) ENGINE=MyISAM AUTO_INCREMENT=552 DEFAULT CHARSET=utf8;

INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('1', 'Secretary', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('2', 'Prinicipal Secretary', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('3', 'Chief Secretary', '40', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('4', 'Secretary', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('5', 'Secretary', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('6', 'Secretary Office ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('7', 'Secretary', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('8', 'Secretary', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('9', 'Secretary', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('10', 'Secretary', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('11', 'Secretary', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('12', 'Secretary', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('13', 'Administration', '34', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('14', 'ACS office', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('15', 'ACS', '42', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('16', 'Secretary', '36', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('17', 'Secretary', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('18', 'Secretary', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('19', 'Secretary', '22', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('20', 'Secretary', '37', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('21', 'Secretary', '34', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('22', 'Secretary', '38', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('23', 'Secretary', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('24', 'Secretary', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('25', 'Secretary', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('26', 'Secretary', '42', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('27', 'Secretary', '9', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('28', 'Secretary', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('29', 'Secretary IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('30', 'Secretary', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('31', 'Secretary', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('32', 'Secretary', '29', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('33', 'Secretary', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('34', 'Secretary', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('35', 'Secretary', '28', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('36', 'Secretary', '18', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('37', 'Secretary', '33', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('38', 'Secretary', '32', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('39', 'SMBR', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('40', 'Secretary', '24', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('41', 'Secretary', '35', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('42', 'Secretary', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('43', 'Secretary', '26', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('44', 'Secretary cum Chief Administrator', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('45', 'Special Secretary  ', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('46', 'Additional Secretary  ', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('47', 'Deputy Secretary Admin', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('48', 'Deputy Secretary University', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('49', 'Deputy Secretary Colleges', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('50', 'Section Officer General', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('51', 'Section Officer Training', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('52', 'Section Officer Account/Budget', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('53', 'Section Officer C1', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('54', 'Section Officer C2', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('55', 'Section Officer C3', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('56', 'Section Officer C4', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('57', 'Section Officer U1', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('58', 'Section Officer U2', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('59', 'Section Officer U3', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('60', 'Section Officer Litigation', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('61', 'HEMIS CELL', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('62', 'Planning Cell', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('63', 'Budget/Accounts', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('64', 'Special Assistant to Minister', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('65', 'Additional Secretary Development', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('66', 'Additional Secretary Establishment', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('67', 'Chief (HSSRU)', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('68', 'Chief Planning Officer', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('69', 'Deputy Director - IT', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('70', 'Deputy Secretary - Drug', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('71', 'Deputy Secretary I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('72', 'Deputy Secretary II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('73', 'Deputy Secretary III', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('74', 'Diary Clerk General Wing', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('75', 'Diary Clerk Secretary', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('76', 'Economist', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('77', 'Planning Officer I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('78', 'Planning Officer II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('79', 'Planning Officer III', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('80', 'Planning Officer IV', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('81', 'Planning Officer V', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('82', 'Section Officer - Budget I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('83', 'Section Officer - Budget II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('84', 'Section Officer - Drug', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('85', 'Section Officer - General', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('86', 'Section Officer - Secret', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('87', 'Section Officer - Coordination', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('88', 'Section Officer I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('89', 'Section Officer II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('90', 'Section Officer III', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('91', 'Section Officer IV', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('92', 'Section Officer V', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('93', 'Section Officer -  Litigation I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('94', 'Section Officer - Litigation II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('95', 'Senior Planning Officer I', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('96', 'Senior Planning Officer II', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('97', 'Senior Planning Officer III', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('98', 'Special Secretary', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('99', 'Additional Secretary', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('100', 'Deputy Secretary', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('101', 'PS to Secretary', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('102', 'SO - General', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('103', 'SO Establishment', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('104', 'SO Budget and Accounts', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('105', 'SO Litigation', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('106', 'Planning Cell', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('107', 'Operationalization of Redesign', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('108', 'Deputy Secretary (Admin), Administartion', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('109', 'SO - (Admin)', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('110', 'Superdent Admin', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('111', 'Computer Cell', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('112', 'Computer Cell', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('113', 'Chief Planning Officer', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('114', 'Additional Secretary', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('115', 'Planning Officer (S&T)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('116', 'Planning Officer (IT)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('117', 'Planning Officer (Monitoring)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('118', 'Deputy Secretary (Admin)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('119', 'Section Officer (B&A)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('120', 'Section Officer (Estb)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('121', 'Section Officer (General)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('122', 'Section Officer (Coordinator)', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('123', 'R&S', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('124', 'Admin', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('125', 'Admin (Field)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('126', 'SO (Admin)', '32', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('127', 'SO (Estab)', '32', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('128', 'IT', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('129', 'PS to Minister', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('130', 'PS to Minister', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('131', 'PS to Minister', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('132', 'Advisor to Minister', '22', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('133', 'PS to Minister', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('134', 'PS to Minister', '25', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('135', 'Special Assistant to Chief Minister', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('136', 'PS to Minister', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('137', 'PS to Minister', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('138', 'PS to Minister', '9', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('139', 'PS to Minister', '10', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('140', 'PS to Minister', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('141', 'Special Assistant to Minister', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('142', 'Special Assistant to CM for Technical Educati', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('143', 'PS to Minister', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('144', 'Advisor to Minister', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('145', 'PS to Minister', '29', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('146', 'PS to Minister', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('147', 'Special Assistant to Minister', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('148', 'PS to Minister', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('149', 'PS to Minister', '28', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('150', 'PS to Minister Office', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('151', 'Advisor to Minister', '18', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('152', 'PS to Minister', '33', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('153', 'PS to Minister', '32', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('154', 'PS to Minister', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('155', 'Special Assistant to Minister', '24', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('156', 'PS to Minister', '20', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('157', 'PS to Minister', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('158', 'Special Assistant  To CM For Transport', '26', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('159', 'PS to Minister', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('160', 'Principal Secretary To Governor ', '43', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('161', 'Special Assistant To CM For LiveStock', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('162', 'Finance Minister', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('163', 'PSO To Finance Minister', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('501', 'Deputy Secretary (Estate), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('500', 'Additional Secretary-I', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('167', 'Special Secretary', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('168', 'Member NFC', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('169', 'Addl: Secretary (A/B)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('170', 'Addl: Secretary (PFC)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('171', 'Addl: Secy (Reg)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('172', 'Addl: Secretary (Dev)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('173', 'Director FMIU', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('174', 'Dy Secretary (PFC)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('175', 'Dy Secretary (Dev-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('176', 'Dy Secretary (Dev-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('177', 'Dy Secretary (NFC-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('178', 'Dy:Sec (Budget-IV)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('179', 'Dy:Sec (Budget-III)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('180', 'Dy:Sec (PAC/Admin)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('181', 'Dy:Sec (B-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('182', 'Dy:Sec (Reg-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('183', 'Dy:Sec:(Reg-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('184', 'Dy:Sec (Resource)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('185', 'Deputy Director FMIU', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('186', 'S.O (Establishment)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('187', 'S.O(Admin)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('188', 'S.O(SR-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('189', 'S.O(SR-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('190', 'S.O(SR-III)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('191', 'S.O(FR)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('192', 'B.O.I', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('193', 'B.O-II', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('194', 'B.O-III', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('195', 'B.O-IV', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('196', 'B.O.V', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('197', 'B.O-VI', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('198', 'B.O.-VII', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('199', 'B.O.-VIII', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('200', 'B.O-XI', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('201', 'B.O-XII', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('202', 'B.O-XIII', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('203', 'BO(PAC/Coordination)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('204', 'BO (PFC-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('205', 'BO(Resource-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('206', 'B.O(Resource-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('207', 'B.O(Resource-III)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('208', 'B.O(Fund/Loan)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('209', 'BO(Ways & Means)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('210', 'SO (ERC)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('211', 'BO (NFC-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('212', 'SO(Dev-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('213', 'SO(Dev-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('214', 'SO(Dev-III)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('215', 'SO(Dev-IV)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('216', 'SO(Lit-I)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('217', 'SO(Lit-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('219', 'Economist CSR Cell', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('220', 'Asstt: Fund Manager', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('221', 'HR Data Base', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('222', 'B.O-IX', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('543', 'B & A Pension ', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('224', 'B.O-X', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('225', 'Assistant Director I', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('226', 'Assistant Director II', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('227', 'Assistant Director III', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('228', 'Assistant Director IV', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('229', 'Assistant Director V', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('230', 'Assistant Director VI', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('231', 'Assistant Director VII', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('232', 'BO(NFC-1)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('233', 'BO (PFC-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('234', 'BO (PFC-III)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('235', 'Assistant Programmer II', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('236', 'Director P&M', '33', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('237', 'Super Admin I&PR', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('238', 'Super Admin Lbr', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('239', 'Super Admin Aqf', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('240', 'Super Admin Law', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('241', 'Super Admin Estab', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('242', 'Super Admin CS', '40', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('243', 'Super Admin(Housing)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('244', 'Super Admin P&DD', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('245', 'Deputy Secretary (R-I)', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('246', 'Section Officer R-I, ESTT', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('247', 'Section Officer R-II', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('248', 'Section officer R-IV', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('249', 'Section Officer PSB, Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('250', 'Section Officer R-VI', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('251', 'Section Officer (Admin)', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('252', 'SO-Administration', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('253', 'Deputy Secretery R-III', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('254', 'Section Officer (General) (LbrD)', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('255', 'info_PO', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('256', 'Section Officer (Labour)_(LbrD)', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('257', 'Deputy Secretary_(LbrD)', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('258', 'Human Rights', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('259', 'Section Officer (Dev)', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('260', 'Section Officer (Auqaf)', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('261', 'Section Officer (HR&MA)', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('262', 'Research Officer_(LbrD)', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('263', 'Additional Secretary_(LbrD)', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('264', 'Special Secretary IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('265', 'Additional Secretary-I IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('266', 'Additional Secretary-II IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('267', 'Assistant Economic Advisor IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('268', 'Deputy Secretary-I IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('269', 'Deputy Secretary-II IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('270', 'Section Officer (Admn) IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('271', 'Section Officer-II IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('272', 'Section Officer-III IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('273', 'Section Officer (Lit) IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('274', 'Section Officer (B&A) IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('275', 'Research Officer-I IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('276', 'Research Officer-II IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('277', 'Financial Analyst IC&TE', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('278', 'SO (B&A)', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('279', 'Section Officer (Admn)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('280', 'Section Officer (Housing)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('281', 'Section Officer (Coord)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('282', 'Section Officer (Litigation)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('283', 'Deputy Secretary (Admn)', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('284', 'Additional Secretary', '13', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('285', 'SO(B&A)', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('286', 'Additional Secretary', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('287', 'Deputy Secretary', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('288', 'Taxation Analyst', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('289', 'Section Officer (Estt)', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('290', 'Section Officer (TAX)', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('291', 'Section Officer (Lit)', '5', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('292', 'Deputy Secretary (Reg-II)', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('293', 'Deputy Secretary (Policy), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('294', 'test', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('295', 'Section Officer (Secret), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('296', 'Section Officer (R-III), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('297', 'Section Officer R-V, establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('298', 'Section Officer (O&M), Establishmnet', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('299', 'Section Officer (Litigation), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('300', 'SO(Information)', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('301', 'Addl. Secretary HRD, Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('302', 'Deputy Secretary HRD, Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('303', 'Section Officer HRD-I, Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('304', 'Section Officer HRD-II, Estbalishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('305', 'Section Officer (B&A)_Labour', '31', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('306', 'personal Assistant', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('307', 'PA to Additional Secretary', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('308', 'Additional Secretary', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('309', 'Private Secretary', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('310', 'SO-(E&A)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('311', 'Section Officer Genaral', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('312', 'Section Officer Litigation ', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('313', 'Section Officer Toursim', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('314', 'SO-(ZBU)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('315', 'SO Agriculture', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('316', 'Section Officer Sports', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('317', 'Parlimentary Secretray To CM', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('318', 'General/Admn Law', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('319', 'Additional Secretary ', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('320', 'Deputy  Secretary ', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('321', 'Section Office Archaeology & Culture ', '21', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('322', 'Legis', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('323', 'Section Officer-III', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('324', 'Legis (DLD)', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('325', 'Opinion', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('326', 'Translator', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('327', 'Assembly', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('328', 'Litigation', '15', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('329', 'SO Admin', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('330', 'SO Establishment', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('331', 'Director', '34', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('350', 'Special Secretary (E), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('332', 'SO Livestock', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('333', 'SO Accounts', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('334', 'SO Litigation', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('335', 'SO (Arms)', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('336', 'Section Officer (Budget)', '18', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('337', 'SO-Budget', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('338', 'Additional Secretary office ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('339', 'Chief Planning Officer', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('340', 'DY Director Planning Agri', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('341', 'DY Director Planning Livestock', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('342', 'AD Planning', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('343', 'Planning Officer', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('344', 'Agri Business Officer', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('345', 'Assistant Statistical Officer', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('346', 'Monitoring Officer', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('347', 'DY Secretary (Admn)', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('348', 'Additional Secretary Agric', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('349', 'Special Secretary Agric', '2', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('351', 'Special Secretary (R), Establishmnet', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('352', 'Addl. Secretary (E), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('353', 'Addl. Secretary (R), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('354', 'Addl. Secretary (Jud), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('355', 'Section Officer-IV', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('356', 'SO-PCMC', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('357', 'SO-(ZCC)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('358', 'Section Officer(General)', '11', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('359', 'Addtional Secretary (Zakat)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('360', 'Deputy Secretary (Admn) (Zakat)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('361', 'Deputy Secretary (Audit) (Zakat)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('362', 'Establishment Section', '28', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('363', 'SOG', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('364', 'Deputy Secretary-III', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('365', 'Additional Secretary', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('366', 'Section Implementation-1', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('367', 'Section Implementation-II', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('368', 'Section Implementation-III', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('369', 'Additional Secretary', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('370', 'Deputy Secretary (Admn)', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('371', 'Deputy Secretary (CCI)', '30', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('372', 'Additional Secretary (Social Welfare)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('373', 'Deputy Secretary (Social Welfare)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('374', 'Deputy Secretary(Admn-SW)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('375', 'Senior Planning Office( SW)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('376', 'MIS (SW)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('377', 'Gender Specialist-I', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('378', 'Gender Specialist-II', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('379', 'Section Officer (General)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('380', 'Section Officer-II (Establishment)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('381', 'Section Officer-III (Budget & Accounts)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('382', 'Section Officer-VI (Special Education)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('383', 'Section Officer (Litigation)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('384', 'SO(Establishment)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('385', 'Chief Economist Office', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('386', 'Deputy Secretary Office', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('387', 'Agriculture ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('388', 'Coordination ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('389', 'EA(Ecnomic Analysis)', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('390', 'Education', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('391', 'Foriegn Aid', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('392', 'Health', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('393', 'Industries', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('394', 'Infrastructure ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('395', 'Power', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('396', 'Director PP&I Office ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('397', 'PSDP', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('398', 'RD(Research,Rural & Regional Development)', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('399', 'SDU', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('400', 'Water', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('401', 'DS-1 Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('402', 'DS-II Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('403', 'SS Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('404', 'AS Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('405', 'SO(General)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('406', 'SO(Technical)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('407', 'SO(Environment)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('408', 'SO(Litigation)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('409', 'B & A Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('410', 'SO - (Audit)', '23', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('411', 'Deputy Secretary (E), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('412', 'Section officer (E-I), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('413', 'Section Officer (E-II), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('414', 'Section Officer (E-III), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('415', 'Section officer (E-IV), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('416', 'Section Officer (E-V), Establishment', '4', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('417', 'Additional Secretary', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('418', 'Deputy Secretary', '3', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('419', 'Section Officer (Aviation-I), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('420', 'Section Officer (Aviation-II), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('421', 'Section Officer (Budget), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('422', 'Resource Centre', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('423', 'CMU(Change Management Unit)', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('424', 'B&A (Budget & Account)', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('425', 'Foreign Training ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('426', 'General ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('427', 'Establishment ', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('428', 'Section Officer (General).', '18', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('429', 'Section Officer (Establishment)', '18', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('430', 'Special Assistant to CM for Industries', '14', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('431', 'Additional Secretary', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('432', 'Special Secretary', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('433', 'Deputy Secretary (Administration)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('434', 'Deputy Secretary (Development)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('435', 'Chief Planning Officer', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('436', 'Secretary Provincial Delimitation Authority', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('437', 'Secretary Local Council Board', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('438', 'Section Officer (General)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('439', 'EPA Section', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('440', 'PP&I', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('441', 'Special Secrertary', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('442', 'Assistant Director-II', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('443', 'SOG', '26', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('444', 'test1', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('445', 'test2', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('446', 'Development', '26', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('447', 'Monitoring Officer I', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('448', 'SOG', '29', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('449', 'Special Secretary ', '41', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('450', 'Reader To SMBR', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('451', 'Secretary-I', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('452', 'Secretary E&SE Office', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('453', 'Special Secretary Office', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('454', 'ESRU', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('455', 'Additional Secretary ', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('456', 'Deputy Secretary (Legal)', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('457', 'PS TO SECRETARY OFFICE', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('458', 'PA TO ADDITIONAL SECRETARY OFFICE', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('459', 'DEPUTY SECRETARY-I', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('460', 'DEPUTY SECRETARY-II ', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('461', 'DEPUTY SECRETARY (LEGAL)', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('462', 'DEPUTY SECRETARY (ADMIN)', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('463', 'PLANNING CELL', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('464', 'EMIS CELL', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('465', 'PROVINCIAL COORDINATOR PFTB', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('466', 'SECTION OFFICER (GENERAL)', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('467', 'SECTION OFFICER COMPLAINT', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('468', 'SECTION OFFICER LITIGATION-1', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('469', 'SECTION OFFICER LITIGATION-II', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('470', 'SECTION OFFICER AUDIT', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('471', 'SECTION OFFICER BUDGET AND ACCOUNT', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('472', 'SECTION OFFICER BOARD AND TRAINING', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('473', 'SECTION OFFICER ACCOUNTS', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('474', 'SECTION OFFICER ASSEMBLY BUSINESS', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('475', 'SECTION OFFICER PRIMARY', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('476', 'SECTION OFFICER SCHOOLS MALE', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('477', 'SECTION OFFICER SCHOOL FEMALE', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('478', 'Secretary 2', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('479', 'MBR-I', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('480', 'Reader To MBR-I', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('481', 'MBR-II', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('482', 'Reader To MBR-II', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('483', 'Assistant Secretary (Admin)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('484', 'Deputy Secretary-I (Revenue)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('485', 'Deputy Secretary-II (Revenue)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('486', 'Budget and Accounts Officer', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('487', 'Assistant Secretary (Stamps)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('488', 'Assistant Secretary (R&S)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('489', 'Assistant Secretary (Lit-I)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('490', 'Assistant Secretary (Lit-II)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('491', 'Assistant Secretary (Receipt)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('492', 'Deputy Secretary(RR&S)', '32', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('493', 'Assistant Secretary (Estt)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('494', 'Budget and Accounts Officer (PAC)', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('495', 'Tehsildar On Special Duty', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('496', 'Special Assistant to CM', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('497', 'Director Land Record Board of Revenue', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('498', 'Project Director Land Record Phase-1', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('499', 'Project Director Land Record Phase-2', '19', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('502', 'Section Officer (Trans.), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('503', 'Section Officer (Implimentation), Administrat', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('504', 'Director Protocol, Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('505', 'Section Officer (Estate), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('506', 'DEPUTY DIRECTOR ESRU', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('507', 'DEPUTY DIRECTOR EMIS', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('508', 'SENIOR PLANNING OFFICER-I', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('509', 'SENIOR PLANNING OFFICER-II', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('510', 'PLANNING OFFICER-I', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('511', 'PLANNING OFFICER-II', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('512', 'Section Officer (Cabinet), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('513', 'Additional Secretary-II, Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('514', 'superintendent (CBA), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('515', 'Superintendent (Admin), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('516', 'Superintendent (Benevolent), Administration', '1', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('517', 'Planning Officer', '27', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('518', 'BOS', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('519', 'Dy Secretary (NFC-II)', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('520', 'Energy Monitoring Cell', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('521', 'Monitoring & Evaluation (M&E)', '17', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('522', 'Section Officer (Litigation)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('523', 'Section Officer (Establishment)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('524', 'Section Officer (Directives)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('525', 'Section Officer (Budget)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('526', 'Directorate General LGRDD', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('527', 'Deputy Director (IT)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('528', 'Assistant Director (IT)', '16', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('529', 'PLANING OFFICER-IV', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('530', 'SECTION OFFICER GENERAL', '7', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('531', 'WL(Establishment)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('532', 'WL(Budget & Account)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('533', 'WL ( P& D)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('534', 'WL_DFO (HQ)', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('535', 'CCWL', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('536', 'Forest_Establishment', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('537', 'Forest_P & D', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('538', 'Forest_Budget', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('539', 'Forest_G B', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('540', 'Forest_R A', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('541', 'Forest_ S O', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('542', 'Forest_ CCF-I', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('544', 'Planning Cell', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('545', 'Assistant Director HEMIS', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('546', 'Web Developer HEMIS', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('547', 'Database Administrator HEMIS', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('548', 'Focal Person HEMIS', '12', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('549', 'Special Assistant to CM for Environment', '6', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('550', 'Assistant Programmer I', '8', '1');
INSERT INTO `section` (`idsection`, `section`, `iddepartment`, `status`) VALUES ('551', 'Home Minister', '11', '1');


#
# TABLE STRUCTURE FOR: source
#

DROP TABLE IF EXISTS `source`;

CREATE TABLE `source` (
  `idsource` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idsource`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `source` (`idsource`, `source`, `status`) VALUES ('1', 'External', '1');
INSERT INTO `source` (`idsource`, `source`, `status`) VALUES ('2', 'Internal', '1');


#
# TABLE STRUCTURE FOR: track
#

DROP TABLE IF EXISTS `track`;

CREATE TABLE `track` (
  `idtrack` int(11) NOT NULL AUTO_INCREMENT,
  `idissue` int(11) NOT NULL,
  `fromdept` int(11) NOT NULL,
  `fromsection` int(11) NOT NULL,
  `todept` int(11) NOT NULL,
  `tosection` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `idfilestatus` int(11) NOT NULL,
  `idusers` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `datetime` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idtrack`),
  KEY `idissue` (`idissue`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: usr_group
#

DROP TABLE IF EXISTS `usr_group`;

CREATE TABLE `usr_group` (
  `GROUP_ID` int(11) NOT NULL,
  `GROUP_NAME` varchar(100) NOT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_USERID` int(11) DEFAULT NULL,
  `UPDATED_DATE` date DEFAULT NULL,
  `UPDATED_USERID` int(11) DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`),
  UNIQUE KEY `UK_GROUP_NAME` (`GROUP_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('1', 'Superadmin', '2015-02-27', '1', NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('2', 'Senior Records Officer', NULL, NULL, NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('3', 'IT Officer', NULL, NULL, NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('4', 'Junior Records Officer', NULL, NULL, NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('5', 'National Service Personnel', NULL, NULL, NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('6', 'NABCO Personnel', NULL, NULL, NULL, NULL);
INSERT INTO `usr_group` (`GROUP_ID`, `GROUP_NAME`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('7', 'ogua', NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: usr_menu
#

DROP TABLE IF EXISTS `usr_menu`;

CREATE TABLE `usr_menu` (
  `MENU_ID` int(11) NOT NULL,
  `MENU_TEXT` varchar(100) DEFAULT NULL,
  `MENU_URL` varchar(500) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `SORT_ORDER` int(11) DEFAULT NULL,
  `MENU_ICON` varchar(25) NOT NULL,
  `SHOW_IN_MENU` int(11) DEFAULT NULL,
  `IS_ADMIN` varchar(1) DEFAULT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_USERID` int(11) DEFAULT NULL,
  `UPDATED_DATE` date DEFAULT NULL,
  `UPDATED_USERID` int(11) DEFAULT NULL,
  PRIMARY KEY (`MENU_ID`),
  KEY `FK_usr_menu_usr_menu_menu_id` (`PARENT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('1', 'User Management', '#', '0', '2', 'fa fa-users', '1', '1', NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('2', 'Add User', 'users/add_user', '1', '2', '', '1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('3', 'General Settings', '#', '0', '3', 'fa fa-cogs', '1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('4', 'Add Menu', 'generals/addmenu', '3', '3', '', '1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('5', 'People', '#', '0', '5', 'fa fa-male', '1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('9', 'List Employees', 'employees/employee_list', '5', '6', '', '1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('21', 'Add Group', 'generals/add_group', '3', '2', '', '1', NULL, '2016-06-16', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('30', 'Incoming Mails', '#', '0', '6', 'fa fa-envelope', '1', NULL, '2018-05-29', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('31', 'Receive Mail', 'Letter/create_file', '30', '1', '', '1', NULL, '2018-05-29', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('32', 'Issued Letters', 'Letter/issued_files', '30', '2', '', '0', NULL, '2018-05-29', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('33', 'Pending Letters', 'Letter/pending_files', '30', '3', '', '0', NULL, '2018-05-29', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('34', 'Received Letters', 'Letter/received_files', '30', '4', '', '0', NULL, '2018-05-29', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('35', 'Received Mails', 'Letter/created_files', '30', '2', '', '1', NULL, '2018-05-31', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('36', 'Forwarded Mails', 'Letter/receive_files', '30', '3', '', '1', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('37', 'Parameters', '#', '0', '4', 'fa fa-briefcase', '1', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('38', 'Department', 'parameters/add_department', '37', '1', '', '0', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('39', 'Mail Types', 'parameters/add_file_type', '37', '2', '', '1', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('40', 'Mail Status', 'parameters/add_file_status', '37', '3', '', '1', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('41', 'Positions', 'parameters/add_designation', '37', '4', '', '0', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('42', 'Returned Mails', 'Letter/returned_files', '30', '4', '', '1', NULL, '2018-06-01', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('43', 'Filed Mails', 'Letter/dispatched_files', '30', '5', '', '1', NULL, '2018-06-02', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('44', 'File Movement', '#', '0', '7', 'fa fa-file-text', '1', NULL, '2018-06-02', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('45', 'Issue File', 'File_movement/file_movement_form', '44', '1', '', '1', NULL, '2018-06-02', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('46', 'Issued Files', 'File_movement/Files', '44', '2', '', '1', NULL, '2018-06-02', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('47', 'Returned Files', 'File_movement/returned_files', '44', '3', '', '1', NULL, '2018-06-03', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('48', 'Outgoing Mails', '#', '0', '8', 'fa fa-reply-all', '1', NULL, '2018-06-04', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('49', 'Dispatch Letter', 'Outgoing_mails/new_file', '48', '1', '', '1', NULL, '2018-06-04', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('50', 'Dispatched Letters', 'Outgoing_mails/outgoingMails', '48', '2', '', '1', NULL, '2018-06-04', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('51', 'Dashboard', '#', '0', '1', '', '1', '1', NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('52', 'Dashboard', 'Dashboard', '51', '1', '', '1', '1', NULL, NULL, NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('53', 'Reports', '#', '0', '12', 'fa fa-bug', '1', NULL, '2018-06-28', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('54', 'Received Letters Report', 'reports/reporting', '53', '1', '', '1', NULL, '2018-06-28', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('55', 'File Name & No', 'Generals/addFilesParameters', '37', '5', '', '1', NULL, '2018-07-14', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('56', 'Backup', '#', '0', '10', 'fa fa-window-restore', '1', NULL, '2018-07-15', '1', NULL, NULL);
INSERT INTO `usr_menu` (`MENU_ID`, `MENU_TEXT`, `MENU_URL`, `PARENT_ID`, `SORT_ORDER`, `MENU_ICON`, `SHOW_IN_MENU`, `IS_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('57', 'Download DB Backup', 'Generals/db_backup', '56', '1', '', '1', NULL, '2018-07-15', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: usr_permission
#

DROP TABLE IF EXISTS `usr_permission`;

CREATE TABLE `usr_permission` (
  `PER_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `MENU_ID` int(11) NOT NULL,
  `PER_SELECT` varchar(1) NOT NULL,
  `PER_INSERT` varchar(1) NOT NULL,
  `PER_UPDATE` varchar(1) NOT NULL,
  `PER_DELETE` varchar(1) NOT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_USERID` int(11) DEFAULT NULL,
  `UPDATED_DATE` date DEFAULT NULL,
  `UPDATED_USERID` int(11) DEFAULT NULL,
  PRIMARY KEY (`PER_ID`),
  KEY `FK_usr_permission_usr_group_group_id` (`GROUP_ID`),
  KEY `FK_usr_permission_usr_menu_menu_id` (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('1', '2', '2', '1', '1', '1', '1', NULL, NULL, '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('2', '2', '3', '1', '0', '0', '0', NULL, NULL, '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('3', '2', '4', '0', '0', '0', '0', NULL, NULL, '2018-05-30', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('4', '2', '5', '1', '0', '0', '0', NULL, NULL, '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('5', '2', '6', '0', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('6', '2', '9', '1', '1', '1', '1', NULL, NULL, '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('7', '2', '10', '0', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('8', '2', '11', '0', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('9', '2', '12', '1', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('10', '2', '13', '1', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('11', '2', '14', '1', '0', '0', '0', NULL, NULL, '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('12', '2', '15', '0', '0', '0', '0', '2015-03-02', '1', '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('13', '2', '16', '0', '0', '0', '0', '2015-03-02', '1', '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('14', '2', '17', '0', '0', '0', '0', '2015-03-02', '1', '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('15', '2', '18', '0', '0', '0', '0', '2015-03-02', '1', '2018-05-30', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('16', '2', '19', '1', '0', '0', '0', '2015-03-02', '1', '2016-06-16', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('17', '1', '2', '1', '1', '1', '1', '2015-03-06', '1', '2020-05-05', '5');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('18', '1', '3', '1', '0', '0', '0', '2015-03-06', '1', '2020-05-05', '5');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('19', '1', '5', '1', '0', '0', '0', '2015-03-06', '1', '2020-05-05', '5');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('20', '1', '6', '0', '0', '0', '0', '2015-03-06', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('21', '1', '9', '1', '1', '1', '1', '2015-03-06', '1', '2020-05-05', '5');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('22', '1', '10', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('23', '1', '11', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('24', '1', '12', '0', '0', '0', '0', '2015-03-06', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('25', '1', '13', '0', '0', '0', '0', '2015-03-06', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('26', '1', '14', '0', '0', '0', '0', '2015-03-06', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('27', '1', '15', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('28', '1', '16', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('29', '1', '17', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('30', '1', '18', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('31', '1', '19', '0', '0', '0', '0', '2015-03-06', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('32', '1', '21', '1', '1', '1', '1', '2015-03-06', '1', '2020-05-05', '5');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('33', '1', '22', '1', '1', '1', '1', '2015-03-06', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('34', '2', '21', '1', '1', '1', '1', '2015-03-16', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('35', '2', '22', '1', '0', '0', '0', '2015-03-16', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('36', '2', '23', '0', '0', '0', '0', '2015-03-16', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('37', '2', '24', '0', '0', '0', '0', '2015-03-16', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('38', '2', '25', '0', '0', '0', '0', '2015-03-16', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('39', '1', '23', '0', '0', '0', '0', '2015-04-15', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('40', '1', '24', '0', '0', '0', '0', '2015-04-15', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('41', '1', '25', '0', '0', '0', '0', '2015-04-15', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('42', '1', '26', '0', '0', '0', '0', '2015-04-15', '1', '2015-04-15', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('43', '2', '26', '0', '0', '0', '0', '2015-09-11', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('44', '2', '27', '0', '0', '0', '0', '2015-09-11', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('45', '2', '28', '0', '0', '0', '0', '2015-09-11', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('46', '2', '29', '0', '0', '0', '0', '2015-09-11', '1', '2017-10-18', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('47', '2', '1', '1', '0', '0', '0', '2016-06-16', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('48', '2', '7', '0', '0', '0', '0', '2016-06-16', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('49', '2', '8', '0', '0', '0', '0', '2016-06-16', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('50', '2', '20', '0', '0', '0', '0', '2016-06-16', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('51', '3', '1', '1', '0', '0', '0', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('52', '3', '2', '1', '1', '1', '1', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('53', '3', '3', '1', '0', '0', '0', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('54', '3', '4', '0', '0', '0', '0', '2017-08-01', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('55', '3', '5', '1', '0', '0', '0', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('56', '3', '9', '1', '1', '1', '1', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('57', '3', '18', '0', '0', '0', '0', '2017-08-01', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('58', '3', '21', '1', '1', '1', '1', '2017-08-01', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('59', '2', '30', '1', '0', '0', '0', '2018-05-30', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('60', '2', '31', '1', '1', '1', '1', '2018-05-30', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('61', '2', '32', '1', '1', '1', '1', '2018-05-30', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('62', '2', '33', '1', '1', '1', '1', '2018-05-30', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('63', '2', '34', '1', '1', '1', '1', '2018-05-30', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('64', '2', '35', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('65', '2', '36', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('66', '2', '37', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('67', '2', '38', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('68', '2', '39', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('69', '2', '40', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('70', '2', '41', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('71', '2', '42', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('72', '2', '43', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('73', '2', '44', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('74', '2', '45', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('75', '2', '46', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('76', '2', '47', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('77', '2', '48', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('78', '2', '49', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('79', '2', '50', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('80', '2', '51', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('81', '2', '52', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('82', '2', '53', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('83', '2', '54', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('84', '2', '55', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('85', '2', '56', '1', '0', '0', '0', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('86', '2', '57', '1', '1', '1', '1', '2018-07-17', '1', '2018-12-12', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('87', '5', '1', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('88', '5', '2', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('89', '5', '3', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('90', '5', '5', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('91', '5', '9', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('92', '5', '21', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('93', '5', '30', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('94', '5', '31', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('95', '5', '32', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('96', '5', '33', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('97', '5', '34', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('98', '5', '35', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('99', '5', '36', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('100', '5', '37', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('101', '5', '38', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('102', '5', '39', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('103', '5', '40', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('104', '5', '41', '0', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('105', '5', '42', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('106', '5', '43', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('107', '5', '44', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('108', '5', '45', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('109', '5', '46', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('110', '5', '47', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('111', '5', '48', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('112', '5', '49', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('113', '5', '50', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('114', '5', '51', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('115', '5', '52', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('116', '5', '53', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('117', '5', '54', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('118', '5', '55', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('119', '5', '56', '1', '0', '0', '0', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('120', '5', '57', '1', '1', '1', '1', '2018-07-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('121', '4', '1', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('122', '4', '2', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('123', '4', '3', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('124', '4', '5', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('125', '4', '9', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('126', '4', '21', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('127', '4', '30', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('128', '4', '31', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('129', '4', '32', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('130', '4', '33', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('131', '4', '34', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('132', '4', '35', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('133', '4', '36', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('134', '4', '37', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('135', '4', '38', '0', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('136', '4', '39', '0', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('137', '4', '40', '0', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('138', '4', '41', '0', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('139', '4', '42', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('140', '4', '43', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('141', '4', '44', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('142', '4', '45', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('143', '4', '46', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('144', '4', '47', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('145', '4', '48', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('146', '4', '49', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('147', '4', '50', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('148', '4', '51', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('149', '4', '52', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('150', '4', '53', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('151', '4', '54', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('152', '4', '55', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('153', '4', '56', '1', '0', '0', '0', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('154', '4', '57', '1', '1', '1', '1', '2018-10-18', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('155', '3', '30', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('156', '3', '31', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('157', '3', '32', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('158', '3', '33', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('159', '3', '34', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('160', '3', '35', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('161', '3', '36', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('162', '3', '37', '1', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('163', '3', '38', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('164', '3', '39', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('165', '3', '40', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('166', '3', '41', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('167', '3', '42', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('168', '3', '43', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('169', '3', '44', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('170', '3', '45', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('171', '3', '46', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('172', '3', '47', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('173', '3', '48', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('174', '3', '49', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('175', '3', '50', '0', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('176', '3', '51', '1', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('177', '3', '52', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('178', '3', '53', '1', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('179', '3', '54', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('180', '3', '55', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('181', '3', '56', '1', '0', '0', '0', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('182', '3', '57', '1', '1', '1', '1', '2019-02-22', '1', '2019-02-22', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('183', '6', '1', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('184', '6', '2', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('185', '6', '3', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('186', '6', '5', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('187', '6', '9', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('188', '6', '21', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('189', '6', '30', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('190', '6', '31', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('191', '6', '32', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('192', '6', '33', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('193', '6', '34', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('194', '6', '35', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('195', '6', '36', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('196', '6', '37', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('197', '6', '38', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('198', '6', '39', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('199', '6', '40', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('200', '6', '41', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('201', '6', '42', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('202', '6', '43', '1', '1', '1', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('203', '6', '44', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('204', '6', '45', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('205', '6', '46', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('206', '6', '47', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('207', '6', '48', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('208', '6', '49', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('209', '6', '50', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('210', '6', '51', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('211', '6', '52', '0', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('212', '6', '53', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('213', '6', '54', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('214', '6', '55', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('215', '6', '56', '1', '0', '0', '0', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('216', '6', '57', '1', '1', '1', '1', '2019-02-22', '1', '2020-05-11', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('217', '7', '1', '1', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('218', '7', '2', '1', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('219', '7', '3', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('220', '7', '5', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('221', '7', '9', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('222', '7', '21', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('223', '7', '30', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('224', '7', '31', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('225', '7', '32', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('226', '7', '33', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('227', '7', '34', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('228', '7', '35', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('229', '7', '36', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('230', '7', '37', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('231', '7', '38', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('232', '7', '39', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('233', '7', '40', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('234', '7', '41', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('235', '7', '42', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('236', '7', '43', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('237', '7', '44', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('238', '7', '45', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('239', '7', '46', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('240', '7', '47', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('241', '7', '48', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('242', '7', '49', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('243', '7', '50', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('244', '7', '51', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('245', '7', '52', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('246', '7', '53', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('247', '7', '54', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('248', '7', '55', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('249', '7', '56', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('250', '7', '57', '0', '0', '0', '0', '2019-06-05', '3', '2020-05-05', '1');
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('251', '1', '1', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('252', '1', '4', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('253', '1', '30', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('254', '1', '31', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('255', '1', '32', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('256', '1', '33', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('257', '1', '34', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('258', '1', '35', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('259', '1', '36', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('260', '1', '37', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('261', '1', '38', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('262', '1', '39', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('263', '1', '40', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('264', '1', '41', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('265', '1', '42', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('266', '1', '43', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('267', '1', '44', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('268', '1', '45', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('269', '1', '46', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('270', '1', '47', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('271', '1', '48', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('272', '1', '49', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('273', '1', '50', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('274', '1', '51', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('275', '1', '52', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('276', '1', '53', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('277', '1', '54', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('278', '1', '55', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('279', '1', '56', '1', '0', '0', '0', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('280', '1', '57', '1', '1', '1', '1', '2020-05-05', '5', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('281', '7', '4', '0', '0', '0', '0', '2020-05-05', '1', NULL, NULL);
INSERT INTO `usr_permission` (`PER_ID`, `GROUP_ID`, `MENU_ID`, `PER_SELECT`, `PER_INSERT`, `PER_UPDATE`, `PER_DELETE`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('282', '6', '4', '0', '0', '0', '0', '2020-05-11', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: usr_user
#

DROP TABLE IF EXISTS `usr_user`;

CREATE TABLE `usr_user` (
  `USER_ID` int(11) NOT NULL,
  `USER_NAME` varchar(100) NOT NULL,
  `U_PASSWORD` varchar(500) NOT NULL,
  `idemployee` int(11) DEFAULT NULL,
  `logged_in` int(1) DEFAULT NULL,
  `IS_ACTIVE` varchar(1) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `SUP_ADMIN` varchar(1) DEFAULT NULL,
  `CREATED_DATE` date DEFAULT NULL,
  `CREATED_USERID` int(11) DEFAULT NULL,
  `UPDATED_DATE` date DEFAULT NULL,
  `UPDATED_USERID` int(11) DEFAULT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `UK_USER_NAME` (`USER_NAME`),
  KEY `FK_usr_user_hrm_employees_emp_no` (`idemployee`),
  KEY `FK_usr_user_usr_group_group_id` (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('1', 'Dennis', 'd1cca52f07876c0c0ce6c35d199c2a112b00dc48', '547', NULL, '1', '1', NULL, NULL, NULL, '2019-02-21', '1');
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('2', 'Bonnah', '7c4a8d09ca3762af61e59520943dc26494f8941b', '548', NULL, '1', '3', NULL, '2019-03-18', '1', NULL, NULL);
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('3', 'ogua', 'd1cca52f07876c0c0ce6c35d199c2a112b00dc48', '0', NULL, '1', '2', NULL, '2019-03-18', '2', NULL, NULL);
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('4', 'junior', '7c4a8d09ca3762af61e59520943dc26494f8941b', '0', NULL, '1', '3', NULL, '2019-06-05', '3', NULL, NULL);
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('5', 'admin', 'd1cca52f07876c0c0ce6c35d199c2a112b00dc48', '549', NULL, '1', '3', NULL, '2019-06-05', '3', NULL, NULL);
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('6', 'admin1', '7c4a8d09ca3762af61e59520943dc26494f8941b', '547', NULL, '1', '7', NULL, '2019-06-05', '3', NULL, NULL);
INSERT INTO `usr_user` (`USER_ID`, `USER_NAME`, `U_PASSWORD`, `idemployee`, `logged_in`, `IS_ACTIVE`, `GROUP_ID`, `SUP_ADMIN`, `CREATED_DATE`, `CREATED_USERID`, `UPDATED_DATE`, `UPDATED_USERID`) VALUES ('7', 'vorsa', 'e613cd38a5ee3dbda92f4302f549a64b1a7606ec', '551', NULL, '1', '6', NULL, '2020-05-11', '1', NULL, NULL);


#
# TABLE STRUCTURE FOR: volume
#

DROP TABLE IF EXISTS `volume`;

CREATE TABLE `volume` (
  `idvolume` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `volume` varchar(45) NOT NULL DEFAULT '',
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`idvolume`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('1', '0', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('2', '1', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('3', '2', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('4', '3', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('5', '4', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('6', '5', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('7', '6', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('8', '7', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('9', '8', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('10', '9', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('11', '10', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('12', '11', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('13', '12', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('14', '13', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('15', '14', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('16', '15', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('17', '16', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('18', '17', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('19', '18', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('20', '19', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('21', '20', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('22', '21', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('23', '22', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('24', '23', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('25', '24', '1');
INSERT INTO `volume` (`idvolume`, `volume`, `status`) VALUES ('26', '25', '1');


