


<?php $__env->startSection('title'); ?>
  Add User Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  Add User Roles
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

          <?php if(session()->has('message')): ?>
	            <div class="alert alert-success">
	                <?php echo e(session('message')); ?>

	            </div>
            <?php endif; ?>
	<div class="row">
      
                <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Assign Permissions</h3>
                </div>
                 <div class="box-body">
                   <form method="post" action="<?php echo e(route('assingn-role-to-permission-save')); ?>">
					<?php echo csrf_field(); ?>
					<label>Check Permssions To Assign for <h3><?php echo e($role->name); ?></h3></label>
					<input type="hidden" name="roleid" value="<?php echo e($role->id); ?>">
				    <div class="box-body">
		              <table class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th>#</th>
		                  <th>User Permissions for <?php echo e($role->name); ?></th>
		                </tr>
		                </thead>
		                <tbody>
		                	<?php $__currentLoopData = $Permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<tr>
		                			<td>
		                				<div class="form-group">
									    <div class="custom-control custom-checkbox">
									      <input type="checkbox" value="<?php echo e($row->id); ?>" class="custom-control-input" id="customCheck1" name="permissions[]"
									      	<?php if($role->permissions->pluck('id')->contains($row->id)): ?> checked
									      	<?php endif; ?>
									      >
									    </div>
									  </div>
		                			</td>
		                			<td><?php echo e($row->name); ?></td>
		                	  </tr>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </tbody>
		             </table>
	            </div>    
				    <input type="submit" name="submit" value="Assign Permission(s) to Role" class="btn btn-success">
				</form> 
                 </div>
                    
              </div>

            </div>


            <div class="col-md-8">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Roles & Permissions</h3>
                </div>
              		<div class="box-body">
		              <table id="example1" class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th>Role</th>
		                  <th>Permission</th>
		                  <th>Edit Perm</th>
		                </tr>
		                </thead>
		                <tbody>
		                	<?php $__currentLoopData = $role_per; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<tr>
		                			<td><?php echo e($row->name); ?></td>
		                			<td>
		                <?php echo e(implode(', ', $row->permissions->pluck('name')->toArray())); ?>

		                			</td>
		                			<td>
							<form action="<?php echo e(route('edit-role-assign-to-permission', ['id'=> $row->id ])); ?>" method="POST">
				       			<?php echo csrf_field(); ?>
				       			<input type="submit" name="submit" class="btn btn-info" value="Edit">
				       			<!-- <a href="#" class="btn btn-info"><i class='fa fa-pencil-square-o'></i>Edit</a> -->
				               </form>	

								</td>
		                	  </tr>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </tbody>
		             </table>
	            </div>    
              </div>
             
            </div>



                  
        </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

   

  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/UserRoles/assign_role.blade.php ENDPATH**/ ?>