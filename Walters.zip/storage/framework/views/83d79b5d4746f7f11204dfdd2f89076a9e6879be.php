


<?php $__env->startSection('title'); ?>
  Force Logout User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  User Management
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

      <div class="panel panel-info">
        <div class="panel panel-heading">Force Logout User</div>
        <div class="panel panel-body">

            <?php if(session()->has('message')): ?>
	            <div class="alert alert-success">
	                <?php echo e(session('message')); ?>

	            </div>
            <?php endif; ?>


            <div class="row">
			
              <div class="col-md-8">	
					<label>Users and Role</h3></label>
				    <div class="box-body">
		              <table id="example1" class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th>img</th>
		                  <th>User</th>
                      <th>user id</th>
		                  <th>Status</th>
		                  <th>Force Logout</th>
		                </tr>
		                </thead>
		                <tbody>
		                	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<tr>

		                			<td>
									             <?php if($row->pro_pic != null): ?>
                <img src=" <?php echo e(asset('storage' )); ?>/<?php echo e($row->pro_pic); ?>" alt="User Image" width="60" height="60">
                    
                               <?php else: ?>
                <img src="<?php echo e(URL::to('images/user.png')); ?>" alt="User Image">

                               <?php endif; ?>
		                			</td>
		                			<td><?php echo e($row->name); ?></td>
                          <td><?php echo e($row->indexnumber); ?></td>
		                			<td>
		                				<?php if($row->is_active == 1): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger" style="background-color: #dd4b39;">Inactive</span>
                            <?php endif; ?>
		                			</td>
                           <?php if($row->force_logout == 0): ?>
                          <td>

        <a href="#" onclick="if(confirm('Are You Sure ?')){ event.preventDefault(); document.getElementById('force_<?php echo e($row->id); ?>').submit(); }" class="btn btn-danger"><i class='fa fa-sign-out'></i>Force Logout</a>
  <form id="force_<?php echo e($row->id); ?>" 
  action="<?php echo e(route('logout-user-force-update', ['id'=> $row->id ])); ?>" method="POST" style="display: none;">
                            
               <?php echo csrf_field(); ?>
                       </form>  
                </td>
                      <?php else: ?>
                      <td>

        <a href="#" onclick="if(confirm('Enable User ?')){ event.preventDefault(); document.getElementById('force_<?php echo e($row->id); ?>').submit(); }" class="btn btn-success"><i class='fa fa-sign-out'></i>Enable User</a>
  <form id="force_<?php echo e($row->id); ?>" 
  action="<?php echo e(route('logout-user-force-enable', ['id'=> $row->id ])); ?>" method="POST" style="display: none;">
                            
               <?php echo csrf_field(); ?>
                       </form>  
                </td>
                <?php endif; ?>

		                	  </tr>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </tbody>
		             </table>
	            </div>    

              </div>
              <div class="col-md-1">
	              
              </div>
			  
			  			  
            </div>
            
            

        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

    

  });

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/UserRoles/alluserforce_logout.blade.php ENDPATH**/ ?>