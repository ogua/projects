


<?php $__env->startSection('title'); ?>
  Walters Dream Big |  Sales Per Day
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  Sales Per Day
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>
      <div class="row">
      
                <!-- left column -->
            <div class="col-md-10">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Sales Per Day</h3>
                </div>
                 <div class="box-body">
                     <div class="box-body table-responsive">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th colspan="6">Sales Per Today</th>
                  </tr>
                <tr>
                  <th>S.N</th>
                  <th>Sold By</th>
                  <th>Branch</th>
                  <th>Product Name</th>
                  <th>Qty Sold</th>
                  <th>Qty BFS</th>
                  <th>Qty AFS</th>
                  <th>Price</th>
                  <th>Description</th>
                  <th>Sold</th>
                </tr>
                </thead>
               
                <tbody>
                  <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td>
                        <?php echo e(auth()->user()->fullname); ?>

                    </td>
                          <td>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($branch->branchode == $row->brancode): ?>
                                <?php echo e($branch->branchloc); ?>

                             <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <td><?php echo e($row->productname); ?></td>
                          <td><?php echo e($row->quantity); ?></td>
                          <td><?php echo e($row->nbs); ?></td>
                          <td><?php echo e($row->nas); ?></td>
                          <td><?php echo e($row->price); ?></td>
                          <td><?php echo e($row->sold); ?></td>
                          <td><?php echo e(\Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
             </table>
            
            </div>    
                 </div>
                    
              </div>

            </div>


        </div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">

  $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

  $('document').ready(function(){

    $(document).on("change","#product-types",function(e){
      e.preventDefault();
      var value = $(this).val();
      //alert(value);
      //return;
      if (value == 'Bundle Product') {
        $("#singledisplay").show();
      }else{
        $("#singledisplay").hide();
      }
    });


    $(document).on("change","#proname",function(e){
      e.preventDefault();
      var value = $(this).val();
      var _token = $('meta[name=csrf-token]').attr('content');
      _this = $(this);
      //alert(value);
      $.ajax({
          url: '<?php echo e(route('search-product')); ?>',
          type: 'POST',
          data: {_token : _token , value: value},
          success: function(data){
            if (data.match("bundel")) {
              $("#singledisplay").show();
            }else{
              $("#singledisplay").hide();
            }
          },
                error: function (data) {
                  console.log('Error:', data);
                  $("#msg").text('Sorry, Something error :(').show();
                }
        });
      
    });


    

  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/Sales/cusview.blade.php ENDPATH**/ ?>