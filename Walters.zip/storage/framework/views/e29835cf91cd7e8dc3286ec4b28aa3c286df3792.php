


<?php $__env->startSection('title'); ?>
Walters Dream Big |  Sales Per Month
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
Sales Per Month
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>
<div class="row">

  <!-- left column -->
  <div class="col-md-12">
    <!-- general form elements -->
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Sales Report</h3>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <labal>Select Date</labal>
                <input type="date" name="cdate" id="cdate" class="form-control">
              </div>
            </div>
            <div class="col-md-6">
              <a href="#" id="getdetails" style="margin-top: 20px;" class="btn btn-success">Search</a>
            </div>
          </div>                   
        </div>
        <div class="col-md-4">
          <lable>Sales Per Month & Year</lable>
          <div class="row">
            <div class="col-md-6">
              <select class="form-control">
                <option>Month</option>
                <option>_________________</option>
                <option value="1">Jan</option>
                <option value="2">Feb</option>
                <option value="3">March</option>
                <option value="4">April</option>
                <option value="5">May</option>
                <option value="6">June</option>
                <option value="7">July</option>
                <option value="8">Aug</option>
                <option value="9">Sep</option>
                <option value="10">Oct</option>
                <option value="11">Nov</option>
                <option value="12">Dec</option>
              </select>
            </div>
            <div class="col-md-6">
             <select class="form-control">
              <option>Year</option>
              <option>2020</option>
              <option>2021</option>
              <option>2022</option>
              <option>2023</option>
              <option>2024</option>
              <option>2025</option>
            </select>
          </div>
        </div>
        <a href="#" id="getsalmnthyear" class="btn btn-success" style="margin-top: 5px;">Search</a>
      </div>
      <div class="col-md-4"></div>
    </div>


    <div class="clearfix"></div>

    <div class="box-body">
      <div class="box-body table-responsive">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
              <th colspan="6">Sales Per Month</th>
            </tr>



            <tr>
              <th colspan="2">Start Date</th>
              <th colspan="2">End Date</th>
              <th colspan="1"></th>
            </tr>

            <tr>
              <th colspan="2"><input type="date" id="data1" class="form-control"></th>
              <th colspan="2"><input type="date" id="data2" class="form-control"></th>
              <th colspan="1"><a href="#" class="btn btn-success" id="searchs">Seach</th>
                <th colspan="1"></th>
              </tr>

              <tr>
                <th>S.N</th>
                <th>Sold By</th>
                <th>Branch</th>
                <th>Product Name</th>
                <th>Qty Sold</th>
                <th>Qty BFS</th>
                <th>Qty AFS</th>
                <th>Price</th>
                <th>Description</th>
                <th>Sold</th>
                <th>Date</th>
              </tr>
            </thead>

            <tbody>
              <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($user->id == $row->user_id): ?>
                  <?php echo e($user->fullname); ?>

                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                  <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($branch->branchode == $row->brancode): ?>
                  <?php echo e($branch->branchloc); ?>

                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <td><?php echo e($row->productname); ?></td>
                  <td><?php echo e($row->quantity); ?></td>
                  <td><?php echo e($row->nbs); ?></td>
                  <td><?php echo e($row->nas); ?></td>
                  <td><?php echo e($row->price); ?></td>
                  <td><?php echo e($row->sold); ?></td>
                  <td><?php echo e(\Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?></td>
                  <td><?php echo e($row->created_at); ?></td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            
          </div>    
        </div>

      </div>

    </div>






  </div>


  <?php $__env->stopSection(); ?>




  <?php $__env->startSection('script'); ?>

  <script type="text/javascript">

    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });

    $('document').ready(function(){

     $(document).on("change","#product-types",function(e){
      e.preventDefault();
      var value = $(this).val();
  		//alert(value);
  		//return;
  		if (value == 'Bundle Product') {
  			$("#singledisplay").show();
  		}else{
  			$("#singledisplay").hide();
  		}
  	});


     $(document).on("change","#proname",function(e){
      e.preventDefault();
      var value = $(this).val();
      var _token = $('meta[name=csrf-token]').attr('content');
      _this = $(this);
  		//alert(value);
  		$.ajax({
       url: '<?php echo e(route('search-product')); ?>',
       type: 'POST',
       data: {_token : _token , value: value},
       success: function(data){
        if (data.match("bundel")) {
         $("#singledisplay").show();
       }else{
         $("#singledisplay").hide();
       }
     },
     error: function (data) {
       console.log('Error:', data);
       $("#msg").text('Sorry, Something error :(').show();
     }
   });
  		
  	});


     $(document).on("click","#searchss",function(e){
      e.preventDefault();

      var sdate = $("#data1").val();
      var edate = $("#data2").val();
      var code = '<?php echo e($code); ?>';

      if (sdate == "") {
       alert("Start Date Cant be Empty");
       return;
     }

     if (edate == "") {
       alert("End Date Cant be Empty");
       return;
     }

     var _token = $('meta[name=csrf-token]').attr('content');
     _this = $(this);

     $.ajax({
       url: '/Walters/DreamBig/salesmonth/data/'+code,
       type: 'POST',
       data: {_token : _token , sdate: sdate, edate: edate},
       success: function(data){
						//alert(data);
						$("#displayhere").html(data);
           $("#data1").val("");
           $("#data2").val("");
         },
         error: function (data) {
           console.log('Error:', data);
           $("#msg").text('Sorry, Something error :(').show();
         }
       });



   });




     $(document).on("click","#searchs",function(e){
      e.preventDefault();

      


      var sdate = $("#data1").val();
      var edate = $("#data2").val();
      var code = '<?php echo e($code); ?>';

      if (sdate == "") {
        alert("Start Date Cant be Empty");
        return;
      }

      if (edate == "") {
        alert("End Date Cant be Empty");
        return;
      }

      // var url = '/Walters/DreamBig/salesmonth/data/'+code+'/'+sdate+'/'+edate;

      //console.log(url);
      //return;


      $('#example1').DataTable({
        processing: true,
        serverSide: true,
        "bDestroy": true,
        ajax: '/Walters/DreamBig/salesmonth/data/'+code+'/'+sdate+'/'+edate,
        dom: 'lBfrtip',
        buttons: [
        'copy',
        'csv',
        'excel',
        'pdf',
        'print'
        ],
        columns: [
        {data:  'DT_RowIndex'},
        {data: 'add_user'},
        {data: 'add_branch'},
        {data: 'productname'},
        {data: 'quantity'},
        {data: 'nbs'},
        {data: 'nas'},
        {data: 'price'},
        {data: 'sold'},
        {data: 'created_at'},
        {data: 'date'}
        ]

      });


      console.log('/Walters/DreamBig/salesmonth/data/'+code+'/'+sdate+'/'+edate);

      $("#data1").val("");
      $("#data2").val("");

      $('#salespermonth').DataTable().fnDestroy();



    });


     $(document).on('click', '#getdetails', function(event) {
      event.preventDefault();
      /* Act on the event */
      var date = $("#cdate").val();
      var code = '<?php echo e($code); ?>';
      if(date == ""){
        alert("Date Cant be Empty");
      }else{


        $('#example1').DataTable({
          processing: true,
          serverSide: true,
          "bDestroy": true,
          ajax: '/Walters/DreamBig/sales/record/perdate/'+code+'/'+date,
          dom: 'lBfrtip',
          buttons: [
          'copy',
          'csv',
          'excel',
          'pdf',
          'print'
          ],
          columns: [
          {data:  'DT_RowIndex'},
          {data: 'add_user'},
          {data: 'add_branch'},
          {data: 'productname'},
          {data: 'quantity'},
          {data: 'nbs'},
          {data: 'nas'},
          {data: 'price'},
          {data: 'sold'},
          {data: 'created_at'},
          {data: 'date'}
          ]

        });

        console.log('/Walters/DreamBig/sales/record/perdate/'+code+'/'+date);

      }
      
    });









   });

 </script>


 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/Sales/salespmonth.blade.php ENDPATH**/ ?>