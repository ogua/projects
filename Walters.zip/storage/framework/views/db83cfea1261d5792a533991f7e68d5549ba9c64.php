                <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                		<tr>
		                  <td><?php echo e($loop->iteration); ?></td>
		                  <td>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($user->id == $row->user_id): ?>
                            <?php echo e($user->fullname); ?>

                          <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			              </td>
                       	  <td>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($branch->branchode == $row->brancode): ?>
                                <?php echo e($branch->branchloc); ?>

                             <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       	  <td><?php echo e($row->productname); ?></td>
                       	  <td><?php echo e($row->quantity); ?></td>
                       	  <td><?php echo e($row->nbs); ?></td>
                       	  <td><?php echo e($row->nas); ?></td>
                       	  <td><?php echo e($row->price); ?></td>
                       	  <td><?php echo e($row->sold); ?></td>
                          <td><?php echo e(\Carbon\Carbon::parse($row->created_at)->diffForHumans()); ?></td>
                       	 
		                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="10">
                        <div class="alert alert-danger">No Record Found</div>
                      </td>
                    </tr>
                	<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/table/print.blade.php ENDPATH**/ ?>