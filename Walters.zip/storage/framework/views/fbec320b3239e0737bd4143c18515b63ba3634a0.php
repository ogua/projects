


<?php $__env->startSection('title'); ?>
  Edit User Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
 Edit User Role
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

		<?php if(session()->has('message')): ?>
	            <div class="alert alert-success">
	                <?php echo e(session('message')); ?>

	            </div>
            <?php endif; ?>

		<div class="row">
      
                <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit User Role / Permission</h3>
                </div>
                 <div class="box-body">
                   	<form method="post" action="<?php echo e(route('edit-role-update')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="hiddenid" value="<?php if(isset($role->id)): ?> <?php echo e($role->id); ?> <?php endif; ?>">
					<input type="hidden" name="type" value="role">
					<div class="form-group  <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				         <label class="control-label" for="inputError">Role name</label>
				         <input type="text" value="<?php if(isset($role->name)): ?> <?php echo e($role->name); ?> <?php endif; ?>" class="form-control" name="role" id="inputError" placeholder="Enter ...">
				          <span class="help-block"><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
				    </div>
				    
				    <input type="submit" name="submit" value="Update Role" class="btn btn-success">
				</form> 

				<hr>

				<form method="post" action="<?php echo e(route('edit-perm-update')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="hiddenid" value="<?php if(isset($Permission->id)): ?> <?php echo e($Permission->id); ?> <?php endif; ?>">
					<input type="hidden" name="type" value="perm">
					<div class="form-group  <?php $__errorArgs = ['Permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				         <label class="control-label" for="inputError">Edit Permission</label>
				         <input type="text" class="form-control" name="Permission" id="inputError" value="<?php if(isset($Permission->name)): ?> <?php echo e($Permission->name); ?> <?php endif; ?>" placeholder="Enter ... Permission">
				          <span class="help-block"><?php $__errorArgs = ['Permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
				    </div>
				    
				    <input type="submit" name="submit" value="Update Permission" class="btn btn-success">
				</form> 
                 </div>
                    
              </div>

            </div>
              
        </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

   

  });

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/UserRoles/editrole_per.blade.php ENDPATH**/ ?>