


<?php $__env->startSection('title'); ?>
   Add UserRole
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  User Management
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>
		
            <?php if(session()->has('message')): ?>
	            <div class="alert alert-success">
	                <?php echo e(session('message')); ?>

	            </div>
            <?php endif; ?>

	  <div class="row">
      
                <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Add User Roles</h3>
                </div>
                 <div class="box-body">
                   	<form method="post" action="<?php echo e(route('user-role-save')); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group  <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				         <label class="control-label" for="inputError">Role name</label>
				         <input type="text" class="form-control" name="role" id="inputError" placeholder="Enter ...">
				          <span class="help-block"><?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
				    </div>
				    
				    <input type="submit" name="submit" value="Add Role" class="btn btn-success">
				</form> 

					<hr>

				<form method="post" action="<?php echo e(route('user-permission-save')); ?>">
					<?php echo csrf_field(); ?>
					<div class="form-group  <?php $__errorArgs = ['Permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
				         <label class="control-label" for="inputError">Add Permission</label>
				         <input type="text" class="form-control" name="Permission" id="inputError" placeholder="Enter ... Permission">
				          <span class="help-block"><?php $__errorArgs = ['Permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
				    </div>
				    
				    <input type="submit" name="submit" value="Add Permission" class="btn btn-success">
				</form> 

                 </div>
                    
              </div>

            </div>


            <div class="col-md-4">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Assign Permissions</h3>
                </div>
              		<table id="example3" class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th>#</th>
		                  <th>User Role</th>
		                  <th>Assign Permission</th>
		                  <th>Edit</th>
		                </tr>
		                </thead>
		                <tbody>
		                	<?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<tr>
		                			<td><?php echo e($loop->iteration); ?></td>
		                			<td><?php echo e($row->name); ?></td>
		                			<td><a href="<?php echo e(route('assingn-role-to-permission', ['id'=>$row->id])); ?>" class="btn btn-success" ><i class='fa fa-lock'></i>Assign</a></td>

		            <td>
				<a href="#" onclick="document.getElementById('dele_doc_<?php echo e($row->id); ?>').submit();" class="btn btn-info"><i class='fa fa-pencil-square-o'></i>Edit</a>
							<form id="dele_doc_<?php echo e($row->id); ?>" 
								action="<?php echo e(route('edit-role-perm', ['id'=> $row->id ])); ?>" method="POST" style="display: none;">			            
							<input type="hidden" name="type" value="role">
				       			<?php echo csrf_field(); ?>
				               </form>	
								</td>

		                		</tr>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </tbody>
		             </table>
              </div>
             
            </div>


            <div class="col-md-4">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">User Permissions</h3>
                </div>
              		<div class="box-body">
		               	<?php if(session()->has('messages')): ?>
			            <div class="alert alert-success">
			                <?php echo e(session('messages')); ?>

			            </div>
		               <?php endif; ?>
		              <table id="example1" class="table table-bordered table-striped">
		                <thead>
		                <tr>
		                  <th>#</th>
		                  <th>User Permissions</th>
		                  <th>Edit</th>
		                </tr>
		                </thead>
		                <tbody>
		                	<?php $__currentLoopData = $Permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                		<tr>
		                			<td><?php echo e($loop->iteration); ?></td>
		                			<td><?php echo e($row->name); ?></td>
		                			<td>
				<a href="#" onclick="document.getElementById('delete_doc_<?php echo e($row->id); ?>').submit();" class="btn btn-info"><i class='fa fa-pencil-square-o'></i>Edit</a>
							<form id="delete_doc_<?php echo e($row->id); ?>" 
								action="<?php echo e(route('edit-role-perm', ['id'=> $row->id ])); ?>" method="POST" style="display: none;">			            
							<input type="hidden" name="type" value="perm">
				       			<?php echo csrf_field(); ?>
				               </form>	
								</td>
		                	  </tr>
		                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </tbody>
		             </table>
	            </div>    
              </div>
             
            </div>



                  
        </div>	


<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

   

  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/UserRoles/addroles.blade.php ENDPATH**/ ?>