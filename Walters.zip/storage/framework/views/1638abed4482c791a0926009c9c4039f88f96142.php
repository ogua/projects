					<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<tr>
		                  <td><?php echo e($loop->iteration); ?></td>
		                  <td>
			                  <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  		<?php if($branch->branchode == $row->branchcode ): ?>
					        			<?php echo e($branch->branchloc); ?>

					        		<?php endif; ?>
					         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					             </td>
                       	  <td><?php echo e($row->productname); ?></td>
                       	  <td><?php echo e($row->productType); ?></td>
                       	  <td><?php echo e($row->quantuty); ?></td>
                       	  <td><?php echo e($row->productprice); ?></td>
                       	  <td>
                       	 <a href="<?php echo e(route('edit-product', ['id'=>$row->id])); ?>" class="btn btn-info" ><i class='fa fa-pencil-square-o'></i>Edit</a>               

                        <a href="<?php echo e(route('delete-product', ['id'=>$row->id])); ?>" class="btn btn-danger"  onclick="return confirm('Are You Sure?')"><i class='fa fa-trash'></i>Delete</a>
                       	  </td>
		                </tr>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/table/products.blade.php ENDPATH**/ ?>