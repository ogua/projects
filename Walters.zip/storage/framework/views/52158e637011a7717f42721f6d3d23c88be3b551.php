


<?php $__env->startSection('title'); ?>
  Walters Dream Big | View Branch
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  View Branch
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

             <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Success!</h4>
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

             <?php if(session()->has('messages')): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i>Alert!</h4>
                    <?php echo e(session('messages')); ?>

                </div>
            <?php endif; ?>
      
            <div class="row">

            <div class="col-md-8">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">All Branches</h3>
                </div>
              
                  <div class="box-body table-responsive">
                      <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                          <th>S.N</th>
                          <th>Branch Code</th>
                          <th>Branch Location</th>
                          <th>Contact</th>
                        </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($row->branchode); ?></td>
                                  <td><?php echo e($row->branchloc); ?></td>
                                  <td><?php echo e($row->contact); ?></td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>    
              </div>
             
            </div>



                  
        </div>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){


  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/branch/view_branch.blade.php ENDPATH**/ ?>