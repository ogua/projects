


<?php $__env->startSection('title'); ?>
  Walters Dream Big | Record Sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  Record Sales
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

      <?php 
          $code = Request::segment(2);
      ?>


       <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Success!</h4>
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

             <?php if(session()->has('messages')): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i>Alert!</h4>
                    <?php echo e(session('messages')); ?>

                </div>
            <?php endif; ?>

         <?php if($agent->isMobile()): ?>            
            <div class="row">
      
                <!-- left column -->
                <div class="col-md-4">
                  <!-- general form elements -->
                  <div class="box box-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title">Record Sales</h3>
                    </div>
                     <div class="box-body">
                         <form method="post" action="" style="margin :4px;" id="recordsales">
                    <?php echo csrf_field(); ?>
                    <div class="form-group  <?php $__errorArgs = ['product-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <label>Select Product</label>
                              <select class="form-control select2" name="product-name"
                               id="proname" style="width: 100%;">
                                <option></option>              
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($product->id); ?>"><?php echo e($product->productname); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>

                              <span class="invalid-feedbac has-error" role="alert" style="color: red;">
                                      <strong id="prodname"></strong>
                              </span>  
                           </div>


                      <div class="form-group  <?php $__errorArgs = ['product-type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"style="display: none;" id="singledisplay">
                           <label class="control-label" for="inputError">Are You Selling All the Bundle or Some of It, Specify</label>
                          <select name="product-type" class="form-control" >
                            <option value="<?php echo e(old('product-type')); ?>"><?php echo e(old('product-type')); ?></option>
                            <option value="Single Product">Selling Single</option>
                            <option value="Bundle Product">Selling Bundle</option>
                          </select>
                      </div>


                       <div class="form-group  <?php $__errorArgs = ['prodcut-qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                           <label class="control-label" for="inputError">Enter Quantity</label>
                           <input type="number" class="form-control" value="<?php echo e(old('prodcut-qty')); ?>" name="prodcut-qty" id="proqty" placeholder="Enter ...">
                            <span class="help-block" id="prdqty" style="color: red;"></span>
                      </div>


                      <div class="form-group  <?php $__errorArgs = ['product-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                           <label class="control-label" for="inputError">Enter Price</label>
                           <input type="number" class="form-control" value="<?php echo e(old('product-price')); ?>" name="product-price" id="propx" placeholder="Enter ...">
                            <span class="help-block" id="prdprx" style="color: red;"></span>
                      </div>


                     
                    <button class="btn btn-success" type="button" disabled id="display" style="display: none;">
                      <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                       Loading...
                    </button>

                      <input type="submit" name="submit" value="Record Sales" class="btn btn-success" id="submit">



                  </form> 
                     </div>
                        
                  </div>

                </div>
                      
            </div>
        <?php else: ?>    
            <div class="row">
              <div class="col-md-4">
                <!-- general form elements -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Record Sales</h3>
                    <a href="<?php echo e(route('new-record-sales',['code'=> $code])); ?>" onclick="return confirm('Record New Sales')" class="pull-right btn btn-success"><i class="fa fa-plus"></i></a>
                  </div>
                   <div class="box-body">
                      <form method="post" action="" style="margin :4px;" id="recordsales">
          <?php echo csrf_field(); ?>
          <div class="form-group  <?php $__errorArgs = ['product-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label>Select Product</label>
                    <select class="form-control select2" name="product-name"
                     id="proname" style="width: 100%;">
                      <option></option>              
                      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($product->id); ?>"><?php echo e($product->productname); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <span class="invalid-feedbac has-error" role="alert" style="color: red;">
                            <strong id="prodname"></strong>
                    </span>  
                 </div>


            <div class="form-group  <?php $__errorArgs = ['product-type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"style="display: none;" id="singledisplay">
                 <label class="control-label" for="inputError">Are You Selling All the Bundle or Some of It, Specify</label>
                <select name="product-type" class="form-control" >
                  <option value="<?php echo e(old('product-type')); ?>"><?php echo e(old('product-type')); ?></option>
                  <option value="Single Product">Selling Pieces</option>
                  <option value="Bundle Product">Selling Bundle</option>
                </select>
            </div>


             <div class="form-group  <?php $__errorArgs = ['prodcut-qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                 <label class="control-label" for="inputError">Enter Quantity</label>
                 <input type="number" class="form-control" value="<?php echo e(old('prodcut-qty')); ?>" name="prodcut-qty" id="proqty" placeholder="Enter ...">
                  <span class="help-block" id="prdqty" style="color: red;"></span>
            </div>

            <div class="form-group  <?php $__errorArgs = ['product-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                 <label class="control-label" for="inputError">Enter Price</label>
                 <input type="number" class="form-control" value="<?php echo e(old('product-price')); ?>" name="product-price" id="propx" placeholder="Enter ...">
                  <span class="help-block" id="prdprx" style="color: red;"></span>
            </div>


         

           
          <button class="btn btn-success" type="button" disabled id="display" style="display: none;">
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
             Loading...
          </button>

            <input type="submit" name="submit" value="Record Sales" class="btn btn-success" id="submit">



        </form> 
                   </div>
                      
                </div>

              </div>
              <div class="col-md-8">
                
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">Sales Display</h3>
                  </div>
                    <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>                  
                <tr>
                  <th>S.N</th>
                  <th>Sold By</th>
                  <th>Branch</th>
                  <th>Product Name</th>
                  <th>Quantity</th>
                  <th>Price</th>
                </tr>

               
                </thead>
               
                <tbody id="showdetails">
                  
                
                </tbody>
             </table>

             <div class="clearfix"></div>
             <div class="col-md-4">
               
             
             <div id="displayit"></div>
            
              <form target="_blank" method="post" action="<?php echo e(route('print-invoice',['code'=> auth()->user()->branncode])); ?>">
                  <?php echo csrf_field(); ?>
                  <tr>
                    <td colspan="2"><input type="text" name="customer" placeholder="customer Name" class="form-control" required></td>

                    <td colspan="2"><input type="text" name="phone" placeholder="Mobile Number" class="form-control" required></td>

                    <!-- <td colspan="1"><a href="" target="_blank" id="prints" class="pull-right btn btn-default">Print Invoice</a></td> -->

                    <td colspan="1"> <input type="submit" name="submit" value="Print Invoice" class="btn btn-default"> </td>
                  </tr>
                </form>

                </div>

            </div>  
                </div>
               
              </div>
                  
            </div>
        <?php endif; ?>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">

  $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

  $('document').ready(function(){

    $(document).on("change","#product-types",function(e){
      e.preventDefault();
      var value = $(this).val();
      //alert(value);
      //return;
      if (value == 'Bundle Product') {
        $("#singledisplay").show();
      }else{
        $("#singledisplay").hide();
      }
    });

    


    $(document).on("change","#proname",function(e){
      e.preventDefault();
      var value = $(this).val();
      var _token = $('meta[name=csrf-token]').attr('content');
      _this = $(this);
      //alert(value);
      $.ajax({
          url: '<?php echo e(route('search-product')); ?>',
          type: 'POST',
          data: {_token : _token , value: value},
          success: function(data){
            if (data.match("bundel")) {
              $("#singledisplay").show();
            }else{
              $("#singledisplay").hide();
            }
          },
                error: function (data) {
                  console.log('Error:', data);
                  $("#msg").text('Sorry, Something error :(').show();
                }
        });
      
    });


     $(document).on("click","#print",function(){
        var mode = 'iframe'; // popup
        var close = mode == "popup";
        var options = { mode : mode, popClose : close};
        $("#example19").printArea(options);
      });



     $(document).on("submit","#recordsales",function(e){
        e.preventDefault();
        //alert('working');

        var prd = $("#proname").val();
        var pqty = $("#proqty").val();
        var propx = $("#propx").val();

        if (prd == "" || pqty == "" || propx == "") {
         
          if (prd == "") {
            $("#prodname").html('Product name cant be empty');
          }else{
            $("#prodname").html('');
          }

          if (pqty == "") {
            $("#prdqty").html('Product name cant be empty');
          }else{
            $("#prdqty").html('');
          }


          if (propx == "") {
            $("#prdprx").html('Product name cant be empty');
          }else{
            $("#prdprx").html('');
          }

          // prodname,prdqty,prdprx
          return;
        }

        $("#prodname").html('');
        $("#prdqty").html('');
        $("#prdprx").html('');

        $.ajax({
          beforeSend:function(){
            $("#display").show();
            $("#submit").hide();
          },complete:function(){
            $("#display").hide();
            $("#submit").show();
          },
          url: '<?php echo e(route('sale-save')); ?>',
          type: 'POST',
          contentType: false,
          processData: false,
          cache: false,
          data: new FormData(this),
          success: function(data){
             $("#alert").html(data);
            $("#proname").val("");
            $("#proqty").val("");
            $("#propx").val("");

             getdetails();
          }
        });
     })

 
     //load datatables

     getdetails();

    function getdetails(){

     var _token = $('meta[name=csrf-token]').attr('content');
      _this = $(this);

      var code = '<?php echo e($code); ?>';

      //alert(code);

      $.ajax({
          url: '/Walters/DreamBig/getyousale/user/'+code,
          type: 'POST',
          data: {_token : _token},
          success: function(data){

            $("#showdetails").html(data);
          },
                error: function (data) {
                  console.log('Error:', data);
                  $("#msg").text('Sorry, Something error :(').show();
                }
        });
    }






  });

</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/Sales/record_sales.blade.php ENDPATH**/ ?>