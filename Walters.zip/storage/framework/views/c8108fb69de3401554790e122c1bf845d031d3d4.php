


<?php $__env->startSection('title'); ?>
  Walters Dream Big | Add Branch
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  Add Branch
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

             <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Success!</h4>
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>

             <?php if(session()->has('messages')): ?>
                <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i>Alert!</h4>
                    <?php echo e(session('messages')); ?>

                </div>
            <?php endif; ?>
      
            <div class="row">
      
                <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Add Branch</h3>
                </div>
               
                    <form method="post" action="<?php echo e(route('save-branch')); ?>" style="margin :4px;">
                      <?php echo csrf_field(); ?>
                          <div class="box-body">
                              <div class="form-group  <?php $__errorArgs = ['branch-location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                     <label class="control-label" for="inputError">Branch Location</label>
                                     <input type="text" class="form-control" value="<?php echo e(old('branch-location')); ?>" name="branch-location" id="inputError" placeholder="Enter ...">
                                      <span class="help-block"><?php $__errorArgs = ['branch-location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>

                                <div class="form-group  <?php $__errorArgs = ['contact-number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                     <label class="control-label" for="inputError">Contact Number</label>
                                     <input type="text" class="form-control" value="<?php echo e(old('contact-number')); ?>" name="contact-number" id="inputError" placeholder="Enter ...">
                                      <span class="help-block"><?php $__errorArgs = ['contact-number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>

                                <input type="submit" name="submit" value="Add Branch" class="btn btn-success">
                            </div>

                    </form> 
              </div>

            </div>


            <div class="col-md-8">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">All Branches</h3>
                </div>
              
                  <div class="box-body table-responsive">
                      <table id="branch" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                          <th>S.N</th>
                          <th>Branch Code</th>
                          <th>Branch Location</th>
                          <th>Contact</th>
                          <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($row->branchode); ?></td>
                                  <td><?php echo e($row->branchloc); ?></td>
                                  <td><?php echo e($row->contact); ?></td>
                                  <td>
                                 <a href="<?php echo e(route('edit-branch', ['id'=>$row->id])); ?>" class="btn btn-info" ><i class='fa fa-pencil-square-o'></i>Edit</a>               
                                 <?php if(auth()->check() && auth()->user()->hasAnyRole('admin')): ?>
                                <a href="<?php echo e(route('delete-branch', ['id'=>$row->id])); ?>" class="btn btn-danger"  onclick="return confirm('Are You Sure?')"><i class='fa fa-trash'></i>Delete</a>
                                <?php endif; ?>
                                  </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                     </table>
                  </div>    
              </div>
             
            </div>



                  
        </div>



<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

    $('#branch').DataTable({
       dom: 'lBfrtip',
      buttons: [
              {
                extend: 'copy',
                itle: 'Walters Branch Information',
                exportOptions: {
                    columns: [ 0, 1, 2, 3, 4]
                }
              },
              {
                extend: 'csv',
                itle: 'Walters Branch Information',
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                }
              },
              {
                extend: 'excel',
                title: 'Walters Branch Information',
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                }
              },
              {
                extend: 'pdf',
                title: 'Branch Information',
                download: 'open',
                footer: true,
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                },
                customize : function(doc) {
                  var rowCount = doc.content[1].table.body.length;
                  for (i = 1; i < rowCount; i++) {
                  doc.content[1].table.body[i][0].alignment = 'center';
                  doc.content[1].table.body[i][1].alignment = 'center';
                  doc.content[1].table.body[i][2].alignment = 'center';
                  doc.content[1].table.body[i][3].alignment = 'center';
                } 
                  doc.content[1].table.widths = [ '20%', '20%', '30%', '30%'];

                }
              },
                
                {
                extend: 'print',
                title: 'Walters Branch Information',
                messageTop: 'All Branches',
                exportOptions: {
                    columns: [ 0, 1, 2, 3]
                },
                customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '10pt' )
                        .prepend(
                            '<img src="<?php echo e(URL::to('images/walter.png')); ?>" style="position:absolute; top:0; left:0;" />'
                        );
 
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .find('.quntity').css("text-align","center")
                        .css( 'font-size', 'inherit' );
                }
              }
      ]
    });
    


    $(document).on("change","#branch",function(e){
      
      var branch = $(this).val();
      alert(branch);
    });

  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/branch/add_branch.blade.php ENDPATH**/ ?>