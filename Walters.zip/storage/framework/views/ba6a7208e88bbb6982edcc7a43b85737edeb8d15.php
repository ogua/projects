


<?php $__env->startSection('title'); ?>
  Walters Dream Big | Add Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mtitle'); ?>
  Add Product
<?php $__env->stopSection(); ?>


<?php $__env->startSection('mtitlesub'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

      <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> Success!</h4>
                    <?php echo e(session('message')); ?>

                </div>
      <?php endif; ?>
      
      <div id="alertdisplay"></div>
       <div class="row">
      
                <!-- left column -->
            <div class="col-md-4">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Add New Product</h3>
                </div>
                <div class="box-body">
                    <form method="post" action="<?php echo e(route('save-product')); ?>" style="margin :4px;" id="saveproductd" >
                        <?php echo csrf_field(); ?>
                        <div class="form-group  <?php $__errorArgs = ['product-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Product Name</label>
                               <input type="text" class="form-control" value="<?php echo e(old('product-name')); ?>" name="product-name" id="prduname" placeholder="Enter ...">
                                <span class="help-block" id="prname" style="color: red;"><?php $__errorArgs = ['product-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>

                          <div class="form-group  <?php $__errorArgs = ['product-type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Product Type</label>
                              <select name="product-type" id="product-type" class="form-control">
                                <option value="<?php echo e(old('product-type')); ?>"><?php echo e(old('product-type')); ?></option>
                                <option value="Single Product">Single Product</option>
                                <option value="Bundle Product">Bundle Product</option>
                              </select>
                              <span class="help-block" id="prdtype" style="color: red;"><?php $__errorArgs = ['product-name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>



                          <div class="form-group  <?php $__errorArgs = ['product-pieces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pieces" style="display: none;">
                               <label class="control-label" for="inputError">Number of Items in Bundle</label>
                             <input type="number" class="form-control" value="<?php echo e(old('product-pieces')); ?>" name="product-pieces" id="prdctpieces" placeholder="Enter ...">
                                <span class="help-block" style="color: red;"><?php $__errorArgs = ['product-pieces'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>



                          <div class="form-group  <?php $__errorArgs = ['product-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Product Price</label>
                               <input type="text" class="form-control" value="<?php echo e(old('product-price')); ?>" name="product-price" id="prodcutpx" placeholder="Enter ...">
                                <span class="help-block" id="prdvtpx" style="color: red;"><?php $__errorArgs = ['product-price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>

                          <div class="form-group  <?php $__errorArgs = ['prodcut-qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Product Quantity</label>
                               <input type="number" class="form-control" value="<?php echo e(old('prodcut-qty')); ?>" name="prodcut-qty" id="prductqty" placeholder="Enter ...">
                                <span class="help-block" id="prdqty" style="color: red;"><?php $__errorArgs = ['prodcut-qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>

                          <div class="form-group  <?php $__errorArgs = ['shortage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Shottage Alert Number</label>
                               <input type="number" class="form-control" value="<?php echo e(old('shortage')); ?>" name="shortage" id="alert" placeholder="Enter ...">
                                <span class="help-block" id="dalert" style="color: red;"><?php $__errorArgs = ['shortage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                          </div>


                          <div class="form-group  <?php $__errorArgs = ['branch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                               <label class="control-label" for="inputError">Product Recorded For Which Branch</label>

                                <select name="branch" id="branch" class="form-control">
                                <option value="<?php echo e(old('branch')); ?>"><?php echo e(old('branch')); ?></option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($branch->branchode); ?>"><?php echo e($branch->branchloc); ?> - Branch</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                              <span class="help-block" id="bcode" style="color: red;"><?php $__errorArgs = ['shortage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>

                          </div>


                          <button class="btn btn-success" type="button" disabled id="display" style="display: none;">
                          <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                           Loading...
                        </button>


                          <input type="submit" name="submit" value="Add Product" class="btn btn-success">
                      </form>  
                  </div> 
                    
              </div>

            </div>


            <div class="col-md-8">
              
              <div class="box box-primary">
                <div class="box-header with-border">
                  <h3 class="box-title">Products Added</h3>
                </div>
                <div class="box-body table-responsive">
                    <table id="products" class="table table-bordered table-striped">
                      <thead>
                      <tr>
                        <th>S.N</th>
                        <th>Branch</th>
                        <th>Product Name</th>
                        <th>Product Type</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th width="25%">Action</th>
                      </tr>
                      </thead>
                      <tbody>
                        
                      </tbody>
                   </table>
                  
                 </div>    
              </div>
             
            </div>



                  
        </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>

<script type="text/javascript">
  $('document').ready(function(){

      $(document).on("change","#product-type",function(e){
        e.preventDefault();
        var value = $(this).val();

        if (value == 'Single Product') {
            $("#pieces").fadeOut(1000);
        }else{
           $("#pieces").fadeIn(1000);
        }

      });


      $(document).on("submit","#saveproductd",function(e){
        e.preventDefault();

        var prduname = $("#prduname").val();
        var prdtype =  $("#product-type").val();
        var prodcutpx = $("#prodcutpx").val();
        var prductqty = $("#prductqty").val(); 
        var alert = $("#alert").val(); 
        var branch = $("#branch").val();


        if (prduname == "" || prdtype == "" || prodcutpx == "" || prductqty == "" || alert == "" || branch == "" ) {

          if (prduname == "") {
            $("#prname").html('Product name cant be Empty');
          }else{
             $("#prname").html('');
          }



          if (prdtype == "") {
            $("#prdtype").html('Product Type cant be Empty');
          }else{
             $("#prdtype").html('');
          }


          if (prodcutpx == "") {
            $("#prdvtpx").html('Product Price cant be Empty');
          }else{
             $("#prdvtpx").html('');
          }



          if (prductqty == "") {
            $("#prdqty").html('Product Quantity cant be Empty');
          }else{
             $("#prdqty").html('');
          }



          if (alert == "") {
            $("#dalert").html('Product Alert cant be Empty');
          }else{
             $("#dalert").html('');
          }


          if (branch == "") {
            $("#bcode").html('Branch cant be Empty');
          }else{
             $("#bcode").html('');
          }

          // prname,prdtype,prdvtpx,prdqty,dalert,bcode


          return;
        }


        $("#prname").html('');
        $("#prdtype").html('');
        $("#prdvtpx").html('');
        $("#prdqty").html('');
        $("#dalert").html('');
        $("#bcode").html('');



        $.ajax({
          beforeSend:function(){
            $("#display").show();
            $("#submit").hide();
          },complete:function(){
            $("#display").hide();
            $("#submit").show();
          },
          url: '<?php echo e(route('save-product')); ?>',
          type: 'POST',
          contentType: false,
          processData: false,
          cache: false,
          data: new FormData(this),
          success: function(data){
             $("#alertdisplay").html(data);
             clearfield();
             $('#products').DataTable().ajax.reload();
          }
        });

      });


      function clearfield(){
        $("#prduname").val("");
        $("#product-type").val("");
        $("#prodcutpx").val("");
        $("#prductqty").val(""); 
       $("#alert").val(""); 
       $("#branch").val("");
      }



      $(document).on("click","#deleteprdct", function(e){
        e.preventDefault();
        var cid = $(this).attr("cid");
        //alert(cid);
        var ajaxs = 'ajax';
        //return;
        if (confirm("Are You Sure ?")) {
          $.ajax({
            url: '/Walters/DreamBig/delete-product/'+cid,
            method: 'get',
            data: {ajaxs: ajaxs},
            success: function(data){
              $("#alertdisplay").html(data);
              $('#products').DataTable().ajax.reload();
            }
          });
        }
      });



    // getdetails();

    // function getdetails(){

    //  var _token = $('meta[name=csrf-token]').attr('content');
    //   _this = $(this);

    //   $.ajax({
    //       url: '/Walters/DreamBig/getproducts/user',
    //       type: 'POST',
    //       data: {_token : _token},
    //       success: function(data){
    //         $("#showdetails").html(data);
    //       },
    //             error: function (data) {
    //               console.log('Error:', data);
    //               $("#msg").text('Sorry, Something error :(').show();
    //             }
    //     });
    // }





$('#products').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route('all-product-display')); ?>',
        dom: 'lBfrtip',
        buttons: [
            'copy',
            'csv',
            'excel',
            'pdf',
            'print'
        ],
        columns: [
            {data: 'DT_RowIndex'},
            {data: 'branchcode'},
            {data: 'productname'},
            {data: 'productType'},
            {data: 'quantuty'},
            {data: 'productprice'},
            {data: 'action', name: 'action'},
        ]




    });








  });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Walters\resources\views/Product/new_product.blade.php ENDPATH**/ ?>