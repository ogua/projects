<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Billmonitor extends Model
{
    protected $fillable = ['bill_id','brancode'];
}
