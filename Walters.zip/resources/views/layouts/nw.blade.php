
<div class="row">
  <div class="col-md-4">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Add Branch</h3>
      </div>
      <div class="box-body">
       
      </div>
    </div>
  </div>
  <div class="col-md-8">
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">All Branches</h3>
      </div>
      
    </div>
  </div>                 
</div>





//single


<div class="row">
  <!-- left column -->
  <div class="col-md-4">
    <!-- general form elements -->
    <div class="box box-primary">
      <div class="box-header with-border">
        <h3 class="box-title">Add Branch</h3>
      </div>
      <div class="box-body">
       
      </div>
    </div>
  </div>
</div>